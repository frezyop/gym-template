# Self-hosted gym service (PHP + MySQL)

The Lovable website is a frontend; it cannot run PHP or host MySQL. This package is a conventional PHP 8.1+ / MySQL 8.0+ REST API for a separate PHP host. No Firebase or Supabase is involved. Do not accept a booking as successful until the API returns a saved reference.

## Requirements

- PHP 8.1+ with `pdo_mysql`, `fileinfo`, `mbstring`, `json`, and file upload support.
- MySQL 8.0+ or MariaDB 10.6+ with InnoDB and JSON support.
- HTTPS on both the website and API hosts. Cross-origin cookies require HTTPS.
- Apache with mod_rewrite and `.htaccess` enabled, or equivalent rewrite rules on Nginx.

## Install

1. Create a database and a dedicated MySQL account using the hosting control panel. Limit access to the one gym database and the API host.
2. Import `schema.sql` with the database owner. It creates the required tables and an intentionally empty starter website. It does not create fake reviews, plans, trainers, or bookings.
3. Copy `config.example.php` to `config.php`. Keep `config.php` outside the public webroot or explicitly block public access. Set the real database, allowed website origin (exact `https://` origin, without a trailing slash), and `app_key`. Never place credentials in the public website.
4. Run `permissions.example.sql` as the database administrator after replacing the database name and, if needed, the MySQL account/host. It grants only table operations the API needs. Do not grant the PHP database account administrative privileges.
5. Set the PHP document root to `backend-php/public/`. Do not expose the parent directory, config file, schema, tests, or source directory. Keep `backend-php/public/uploads/` writable by the PHP account and unavailable for script execution.
6. Create the first admin account from a private SSH/CLI shell after configuring `config.php` and importing the schema:

   ```sh
   GYM_ADMIN_EMAIL='owner@example.com' GYM_ADMIN_PASSWORD='use-a-unique-password-at-least-12-characters' php backend-php/bin/create-admin.php
   ```

   Supply a unique password securely through the host's secret/environment interface, not a public command history if avoidable. Passwords are stored as PHP `password_hash()` output. The one-time initializer refuses to create a second account. There is no public signup route.

7. Check `https://api.example.com/health`; it should return `{"ok":true}`. Check `https://api.example.com/auth/csrf` in a browser from the configured website origin; it should return JSON and set an HttpOnly session cookie.
8. Configure the frontend's public build-time variable `VITE_GYM_API_URL=https://api.example.com` in the website hosting/build settings (not as a secret and not in a committed private `.env`). Rebuild/re-publish the frontend. The browser needs this base URL to call the API; no credential is placed there.
9. Sign in at `/admin`, complete website details and opening hours, upload the owner's images, and test a booking, conflict handling, status changes, and sign-out.

## API endpoints

- `GET /health` — service health check.
- `GET /auth/csrf` — token plus secure session cookie.
- `POST /auth/login` — email/password, CSRF checked, throttled, rotates the session ID.
- `GET /auth/session` and `POST /auth/logout` — private session state and CSRF-protected logout.
- `GET /public/site` — only published public content.
- `GET /public/bookings/slots?date=YYYY-MM-DD` — available hourly starts for confirmed opening hours, excluding accepted appointments.
- `POST /public/bookings` — validates details, consent, date, time and purpose; stores a `Pending` record and returns its unique reference.
- `GET /admin/site`, `PUT /admin/site` — protected site content read and permanent save.
- `GET /admin/bookings?status=&date=&search=` — protected appointment list, newest first (up to 500 matches).
- `PATCH /admin/bookings/{id}` — protected status, reschedule and private-note changes. Accepted appointments reserve a unique date/time; a conflict returns HTTP 409.
- `POST /admin/uploads` — protected JPEG/PNG/WebP uploads (8 MiB default, capped at 10 MiB), MIME/signature checked, randomized filename in persistent `public/uploads/`.

JSON writes use prepared PDO statements, size/type/length checks, strict allow-lists and CSRF tokens. The origin allow-list is exact-match; allow only the public site origin. Public callers cannot query bookings or mutate the website. Login/booking attempt limits use `request_limits`; temporary old counters are pruned on later requests. Customer data is only available through authenticated admin endpoints.

## Configuration notes

- Set the API session cookie `Secure`, `HttpOnly`, and `SameSite=None` for HTTPS cross-origin website/API use; the bundled defaults do this. For a single shared origin, `SameSite=Lax` may be preferred.
- Set PHP's timezone to the gym's local timezone so the date cutoff, appointment date and displayed opening hours align.
- `config.example.php` is only a template. A working database user/password and a random app key are required. Generate the app key on the server with `php -r 'echo bin2hex(random_bytes(32)), PHP_EOL;'` and store it in private host configuration.
- Apache must honor the included rewrites; on Nginx, route unknown API paths to `public/index.php` and deny PHP execution under `public/uploads/`.
- The API returns no owner-notification email; it stores bookings. Email delivery requires a separately configured SMTP provider and a tested sender domain; no SMTP credentials are included or sent to the browser.
- The initial HTML preview includes generated photography as design assets. The owner should replace it with approved business photos. Generated coach imagery is not a real trainer and must not be represented as one.

## Test checklist

Run the calendar-date helper check from the project root with `php backend-php/tests/validation-test.php` before deployment. It verifies that historic calendar dates can be searched while malformed dates are rejected.

- [ ] `/health` responds over HTTPS; requests from an unrelated origin cannot read API responses.
- [ ] Missing `config.php`, bad database credentials, and unwritable image storage show an error, never a success response.
- [ ] No admin account exists publicly; wrong passwords fail; after CLI initialization the owner can sign in and sign out.
- [ ] An unauthenticated caller cannot read site settings or appointment/customer details, upload files, or change statuses.
- [ ] Valid CSRF allows admin saves; missing/incorrect CSRF rejects them.
- [ ] Each invalid/missing booking field, missing consent, invalid purpose/time, malformed date, and past date is rejected server-side.
- [ ] A valid booking persists with a 12-character unique reference and `Pending` status; success is returned only after commit.
- [ ] Opening/closing hours determine slot choices; closing times do not produce an out-of-hours slot.
- [ ] Two accepted appointments cannot take the same start time. Pending requests may overlap until one is accepted.
- [ ] Accept, reject, cancel, complete, reschedule and private notes persist and appear after reloading `/admin`.
- [ ] Search, date and status filters; confirm conflict messages when a requested time is already reserved.
- [ ] Upload invalid MIME, oversized and valid JPG/PNG/WebP files; verify only valid files are served as images and survive a restart.
- [ ] Change public text, save it, then open `/` in a fresh browser and verify it reads from the database.
- [ ] Replace all generated/sample visuals and confirm actual business address, hours, map, phone, email, legal privacy text, and any testimonials before publishing.
