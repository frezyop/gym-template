<?php
declare(strict_types=1);

// Copy this file to config.php OUTSIDE the public webroot where possible.
return [
    'db' => [
        'host' => getenv('GYM_DB_HOST') ?: '127.0.0.1',
        'port' => getenv('GYM_DB_PORT') ?: '3306',
        'name' => getenv('GYM_DB_NAME') ?: 'gym_app',
        'user' => getenv('GYM_DB_USER') ?: 'replace_me',
        'password' => getenv('GYM_DB_PASSWORD') ?: 'replace_me',
        'charset' => 'utf8mb4',
    ],
    // Exact frontend origin, for example https://gym.example.com (no trailing slash).
    'allowed_origin' => getenv('GYM_ALLOWED_ORIGIN') ?: 'https://replace-with-your-site.example',
    // At least 32 random bytes. Generate with: php -r 'echo bin2hex(random_bytes(32)), PHP_EOL;'
    'app_key' => getenv('GYM_APP_KEY') ?: 'replace-with-a-long-random-secret',
    'session_name' => 'gym_admin_session',
    'max_upload_bytes' => 8 * 1024 * 1024,
];
