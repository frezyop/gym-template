<?php
declare(strict_types=1);

require dirname(__DIR__) . '/src/validation.php';

$cases = [
    ['2025-01-15', true],
    ['2099-10-27', true],
    ['2025-02-30', false],
    ['not-a-date', false],
];

foreach ($cases as [$date, $expected]) {
    if (gym_valid_calendar_date($date) !== $expected) {
        throw new RuntimeException('Calendar date validation failed for ' . $date);
    }
}

if (gym_valid_date('2000-01-01')) {
    throw new RuntimeException('Booking validation must reject a past appointment date.');
}

fwrite(STDOUT, "Calendar date validation passed.\n");