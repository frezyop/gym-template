CREATE TABLE admins (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(254) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_login_at TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE site_settings (
    id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
    content_json JSON NOT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT single_site_settings_row CHECK (id = 1)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO site_settings (id, content_json) VALUES (1, JSON_OBJECT(
    'brand', JSON_OBJECT('name', 'Your Gym', 'descriptor', 'STRENGTH CLUB', 'tagline', '', 'logoUrl', '', 'faviconUrl', '', 'accentColor', '#ef4038', 'instagramUrl', '', 'facebookUrl', '', 'youtubeUrl', ''),
    'hero', JSON_OBJECT('eyebrow', 'YOUR GYM · YOUR STORY', 'title', 'TRAIN WITH\nINTENT.', 'description', 'Add a verified introduction to your gym.', 'primaryLabel', 'Explore membership', 'secondaryLabel', 'Book a visit', 'imageUrl', '', 'imageAlt', ''),
    'about', JSON_OBJECT('title', 'A stronger start.', 'description', 'Add an accurate introduction to your business.', 'highlights', JSON_ARRAY()),
    'plans', JSON_ARRAY(), 'trainers', JSON_ARRAY(), 'gallery', JSON_ARRAY(), 'classes', JSON_ARRAY(), 'testimonials', JSON_ARRAY(),
    'contact', JSON_OBJECT('phone', '', 'whatsapp', '', 'email', '', 'address', '', 'mapsEmbedUrl', '', 'directionsUrl', '', 'businessInfoVerified', false,
        'openingHours', JSON_ARRAY(
            JSON_OBJECT('day', 'Monday', 'open', '', 'close', '', 'closed', true),
            JSON_OBJECT('day', 'Tuesday', 'open', '', 'close', '', 'closed', true),
            JSON_OBJECT('day', 'Wednesday', 'open', '', 'close', '', 'closed', true),
            JSON_OBJECT('day', 'Thursday', 'open', '', 'close', '', 'closed', true),
            JSON_OBJECT('day', 'Friday', 'open', '', 'close', '', 'closed', true),
            JSON_OBJECT('day', 'Saturday', 'open', '', 'close', '', 'closed', true),
            JSON_OBJECT('day', 'Sunday', 'open', '', 'close', '', 'closed', true)
        )
    ),
    'seo', JSON_OBJECT('title', 'Your Gym', 'description', 'Gym information will be updated by the business owner.')
));

CREATE TABLE bookings (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    reference CHAR(12) CHARACTER SET ascii COLLATE ascii_bin NOT NULL UNIQUE,
    full_name VARCHAR(120) NOT NULL,
    phone VARCHAR(30) NOT NULL,
    email VARCHAR(254) NOT NULL,
    appointment_date DATE NOT NULL,
    time_slot CHAR(5) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    purpose ENUM('Gym Tour', 'Free Trial', 'Personal Training Consultation', 'Membership Enquiry') NOT NULL,
    message VARCHAR(1000) NOT NULL DEFAULT '',
    privacy_consent TINYINT(1) NOT NULL,
    status ENUM('Pending', 'Accepted', 'Rejected', 'Cancelled', 'Completed') NOT NULL DEFAULT 'Pending',
    confirmed_slot VARCHAR(32) CHARACTER SET ascii COLLATE ascii_bin NULL UNIQUE,
    admin_notes VARCHAR(2000) NOT NULL DEFAULT '',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX bookings_date_idx (appointment_date),
    INDEX bookings_status_idx (status),
    INDEX bookings_customer_idx (full_name, email),
    INDEX bookings_date_time_idx (appointment_date, time_slot),
    CONSTRAINT bookings_accepted_slot_matches_date_time CHECK (status <> 'Accepted' OR confirmed_slot = CONCAT(appointment_date, ' ', time_slot)),
    CONSTRAINT bookings_unconfirmed_have_no_reserved_slot CHECK (status = 'Accepted' OR confirmed_slot IS NULL)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE request_limits (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    limit_key CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX request_limits_key_created_at_idx (limit_key, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
