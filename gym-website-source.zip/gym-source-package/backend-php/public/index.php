<?php
declare(strict_types=1);

$configPath = dirname(__DIR__) . '/config.php';
if (!is_file($configPath)) {
    http_response_code(503);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => 'The gym service is not configured yet.']);
    exit;
}
$config = require $configPath;
require dirname(__DIR__) . '/src/database.php';
require dirname(__DIR__) . '/src/http.php';
require dirname(__DIR__) . '/src/validation.php';

$allowedOrigin = (string) ($config['allowed_origin'] ?? '');
$origin = (string) ($_SERVER['HTTP_ORIGIN'] ?? '');
if ($origin !== '' && hash_equals($allowedOrigin, $origin)) {
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Access-Control-Allow-Credentials: true');
    header('Vary: Origin');
}
header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-CSRF-Token, Accept');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Cross-Origin-Resource-Policy: cross-origin');
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') { http_response_code(204); exit; }

try {
    gym_start_session($config);
    $pdo = gym_db($config);
    $path = parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH) ?: '/';
    $method = (string) ($_SERVER['REQUEST_METHOD'] ?? 'GET');

    if ($path === '/health' && $method === 'GET') gym_json(['ok' => true]);
    if ($path === '/auth/csrf' && $method === 'GET') gym_json(['csrfToken' => gym_csrf_token()]);

    if ($path === '/auth/login' && $method === 'POST') {
        gym_require_csrf();
        gym_limit($pdo, $config, 'login', gym_remote_identity(), 12, 900);
        $input = gym_read_json();
        $email = strtolower(trim(gym_string($input, 'username', 254)));
        $password = gym_string($input, 'password', 200, false);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 1) gym_fail('Enter a valid email and password.', 422);
        $stmt = $pdo->prepare('SELECT id, password_hash, active FROM admins WHERE email = :email LIMIT 1');
        $stmt->execute(['email' => $email]);
        $admin = $stmt->fetch();
        if (!$admin || !(bool) $admin['active'] || !password_verify($password, (string) $admin['password_hash'])) gym_fail('Email or password is incorrect.', 401);
        session_regenerate_id(true);
        $_SESSION['admin_id'] = (int) $admin['id'];
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        $pdo->prepare('UPDATE admins SET last_login_at = CURRENT_TIMESTAMP WHERE id = :id')->execute(['id' => (int) $admin['id']]);
        gym_json(['authenticated' => true, 'csrfToken' => $_SESSION['csrf_token']]);
    }

    if ($path === '/auth/session' && $method === 'GET') gym_json(['authenticated' => isset($_SESSION['admin_id'])]);
    if ($path === '/auth/logout' && $method === 'POST') {
        gym_require_admin(); gym_require_csrf();
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', ['expires' => time() - 42000, 'path' => $params['path'], 'secure' => true, 'httponly' => true, 'samesite' => 'None']);
        }
        session_destroy();
        gym_json(['signedOut' => true]);
    }

    if ($path === '/public/site' && $method === 'GET') {
        $content = $pdo->query('SELECT content_json FROM site_settings WHERE id = 1')->fetchColumn();
        gym_json(['content' => is_string($content) ? json_decode($content, true) : null]);
    }

    if ($path === '/public/bookings/slots' && $method === 'GET') {
        $date = (string) ($_GET['date'] ?? '');
        if (!gym_valid_date($date)) gym_fail('Choose a valid date.', 422);
        $content = gym_load_content($pdo);
        $slots = gym_slots($content, $date);
        $stmt = $pdo->prepare("SELECT time_slot FROM bookings WHERE appointment_date = :date AND status = 'Accepted'");
        $stmt->execute(['date' => $date]);
        $blocked = array_column($stmt->fetchAll(), 'time_slot');
        gym_json(['slots' => array_values(array_diff($slots, $blocked))]);
    }

    if ($path === '/public/bookings' && $method === 'POST') {
        gym_limit($pdo, $config, 'booking', gym_remote_identity(), 8, 3600);
        $input = gym_read_json();
        $booking = gym_validate_booking($input, gym_load_content($pdo));
        $reference = strtoupper(bin2hex(random_bytes(6)));
        $stmt = $pdo->prepare("INSERT INTO bookings (reference, full_name, phone, email, appointment_date, time_slot, purpose, message, privacy_consent, status) VALUES (:reference, :name, :phone, :email, :date, :slot, :purpose, :message, 1, 'Pending')");
        $stmt->execute(['reference' => $reference, 'name' => $booking['fullName'], 'phone' => $booking['phone'], 'email' => $booking['email'], 'date' => $booking['appointmentDate'], 'slot' => $booking['timeSlot'], 'purpose' => $booking['purpose'], 'message' => $booking['message']]);
        gym_json(['reference' => $reference, 'status' => 'Pending'], 201);
    }

    if (str_starts_with($path, '/admin/')) gym_require_admin();

    if ($path === '/admin/session' && $method === 'GET') gym_json(['authenticated' => isset($_SESSION['admin_id'])]);

    if ($path === '/admin/site' && $method === 'GET') {
        $content = $pdo->query('SELECT content_json FROM site_settings WHERE id = 1')->fetchColumn();
        gym_json(['content' => is_string($content) ? json_decode($content, true) : null]);
    }

    if ($path === '/admin/site' && $method === 'PUT') {
        gym_require_csrf();
        $body = gym_read_json();
        if (!isset($body['content']) || !is_array($body['content'])) gym_fail('Website content is required.', 422);
        $content = gym_clean_content($body['content']);
        $stmt = $pdo->prepare('UPDATE site_settings SET content_json = :content WHERE id = 1');
        $stmt->execute(['content' => json_encode($content, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)]);
        gym_json(['saved' => true]);
    }

    if ($path === '/admin/bookings' && $method === 'GET') {
        $status = (string) ($_GET['status'] ?? '');
        $date = (string) ($_GET['date'] ?? '');
        $search = trim((string) ($_GET['search'] ?? ''));
        if ($status !== '' && !in_array($status, gym_statuses(), true)) gym_fail('Invalid status filter.', 422);
        if ($date !== '' && !gym_valid_calendar_date($date)) gym_fail('Invalid date filter.', 422);
        if (strlen($search) > 100) gym_fail('Search text is too long.', 422);
        $where = []; $params = [];
        if ($status !== '') { $where[] = 'status = :status'; $params['status'] = $status; }
        if ($date !== '') { $where[] = 'appointment_date = :date'; $params['date'] = $date; }
        if ($search !== '') {
            $where[] = '(full_name LIKE :query_name OR email LIKE :query_email OR phone LIKE :query_phone OR reference LIKE :query_reference)';
            $query = '%' . gym_like_escape($search) . '%';
            $params['query_name'] = $query;
            $params['query_email'] = $query;
            $params['query_phone'] = $query;
            $params['query_reference'] = $query;
        }
        $sql = 'SELECT id, reference, full_name, phone, email, appointment_date, time_slot, purpose, message, status, admin_notes, created_at FROM bookings' . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . ' ORDER BY created_at DESC LIMIT 500';
        $stmt = $pdo->prepare($sql); $stmt->execute($params);
        $bookings = array_map('gym_public_booking_shape', $stmt->fetchAll());
        $counts = array_fill_keys(gym_statuses(), 0);
        foreach ($pdo->query('SELECT status, COUNT(*) AS total FROM bookings GROUP BY status')->fetchAll() as $row) $counts[(string) $row['status']] = (int) $row['total'];
        gym_json(['bookings' => $bookings, 'counts' => $counts]);
    }

    if (preg_match('#^/admin/bookings/(\d+)$#', $path, $matches) && $method === 'PATCH') {
        gym_require_csrf();
        $id = (int) $matches[1];
        $body = gym_read_json();
        $stmt = $pdo->prepare('SELECT * FROM bookings WHERE id = :id FOR UPDATE');
        $pdo->beginTransaction(); $stmt->execute(['id' => $id]); $current = $stmt->fetch();
        if (!$current) { $pdo->rollBack(); gym_fail('Appointment was not found.', 404); }
        $status = array_key_exists('status', $body) ? gym_valid_status((string) $body['status']) : (string) $current['status'];
        $date = array_key_exists('appointmentDate', $body) ? (string) $body['appointmentDate'] : (string) $current['appointment_date'];
        $slot = array_key_exists('timeSlot', $body) ? (string) $body['timeSlot'] : (string) $current['time_slot'];
        $notes = array_key_exists('adminNotes', $body) ? gym_text_value($body['adminNotes'], 2000, 'Admin notes') : (string) $current['admin_notes'];
        if (!gym_valid_date($date) || !preg_match('/^(?:[01]\d|2[0-3]):00$/', $slot)) { $pdo->rollBack(); gym_fail('Choose a valid appointment date and time.', 422); }
        if ($date < date('Y-m-d')) { $pdo->rollBack(); gym_fail('Appointments cannot be scheduled in the past.', 422); }
        if ($status === 'Accepted' && !in_array($slot, gym_slots(gym_load_content($pdo), $date), true)) { $pdo->rollBack(); gym_fail('This time is outside the gym’s configured opening hours.', 422); }
        $confirmed = $status === 'Accepted' ? $date . ' ' . $slot : null;
        try {
            $update = $pdo->prepare('UPDATE bookings SET status = :status, appointment_date = :date, time_slot = :slot, admin_notes = :notes, confirmed_slot = :confirmed WHERE id = :id');
            $update->execute(['status' => $status, 'date' => $date, 'slot' => $slot, 'notes' => $notes, 'confirmed' => $confirmed, 'id' => $id]);
            $pdo->commit();
        } catch (PDOException $error) {
            $pdo->rollBack();
            if ((string) $error->getCode() === '23000') gym_fail('That confirmed appointment time is already taken.', 409);
            throw $error;
        }
        $read = $pdo->prepare('SELECT id, reference, full_name, phone, email, appointment_date, time_slot, purpose, message, status, admin_notes, created_at FROM bookings WHERE id = :id');
        $read->execute(['id' => $id]);
        gym_json(['booking' => gym_public_booking_shape($read->fetch())]);
    }

    if ($path === '/admin/uploads' && $method === 'POST') {
        gym_require_csrf();
        $file = $_FILES['image'] ?? null;
        if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file((string) ($file['tmp_name'] ?? ''))) gym_fail('Choose an image to upload.', 422);
        $maxBytes = min(10 * 1024 * 1024, max(1024, (int) ($config['max_upload_bytes'] ?? 8 * 1024 * 1024)));
        if ((int) $file['size'] < 1 || (int) $file['size'] > $maxBytes) gym_fail('Images must be smaller than ' . (int) floor($maxBytes / 1024 / 1024) . ' MB.', 413);
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file((string) $file['tmp_name']);
        $extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
        if (!is_string($mime) || !isset($extensions[$mime]) || @getimagesize((string) $file['tmp_name']) === false) gym_fail('Upload a valid JPG, PNG or WebP image.', 415);
        $uploadDir = __DIR__ . '/uploads';
        if (!is_dir($uploadDir) && !mkdir($uploadDir, 0750, true) && !is_dir($uploadDir)) gym_fail('Image storage is unavailable.', 500);
        $filename = bin2hex(random_bytes(18)) . '.' . $extensions[$mime];
        if (!move_uploaded_file((string) $file['tmp_name'], $uploadDir . '/' . $filename)) gym_fail('Image could not be stored.', 500);
        gym_json(['url' => '/uploads/' . $filename], 201);
    }

    gym_fail('Endpoint not found.', 404);
} catch (Throwable $error) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) $pdo->rollBack();
    error_log('Gym API failure: ' . $error->getMessage());
    gym_json(['error' => $error instanceof RuntimeException ? 'The gym service is temporarily unavailable. Check its server configuration.' : 'The request could not be completed. Please try again.'], 500);
}
