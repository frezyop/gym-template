<?php
declare(strict_types=1);

function gym_string(array $input, string $key, int $max, bool $trim = true): string
{
    $value = $input[$key] ?? null;
    if (!is_string($value) || strlen($value) > $max) gym_fail('Check the ' . $key . ' field.', 422);
    $value = $trim ? trim($value) : $value;
    if ($trim && $value === '') gym_fail('The ' . $key . ' field is required.', 422);
    return $value;
}

function gym_text_value(mixed $value, int $max, string $label): string
{
    if (!is_string($value) || strlen($value) > $max) gym_fail($label . ' is too long or invalid.', 422);
    return trim($value);
}

function gym_valid_calendar_date(string $date): bool
{
    $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
    return $parsed !== false && $parsed->format('Y-m-d') === $date;
}

function gym_valid_date(string $date): bool
{
    return gym_valid_calendar_date($date) && $date >= date('Y-m-d');
}

function gym_statuses(): array { return ['Pending', 'Accepted', 'Rejected', 'Cancelled', 'Completed']; }
function gym_valid_status(string $status): string
{
    if (!in_array($status, gym_statuses(), true)) gym_fail('Choose a valid appointment status.', 422);
    return $status;
}

function gym_load_content(PDO $pdo): array
{
    $raw = $pdo->query('SELECT content_json FROM site_settings WHERE id = 1')->fetchColumn();
    $content = is_string($raw) ? json_decode($raw, true) : null;
    return is_array($content) ? $content : [];
}

function gym_slots(array $content, string $date): array
{
    if (!gym_valid_date($date)) return [];
    $openingHours = $content['contact']['openingHours'] ?? [];
    if (!is_array($openingHours)) return [];
    $weekday = ((int) (new DateTimeImmutable($date))->format('N')) - 1;
    $hours = $openingHours[$weekday] ?? null;
    if (!is_array($hours) || ($hours['closed'] ?? true) === true) return [];
    $open = (string) ($hours['open'] ?? ''); $close = (string) ($hours['close'] ?? '');
    if (!preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $open) || !preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $close)) return [];
    [$openHour, $openMinute] = array_map('intval', explode(':', $open));
    [$closeHour, $closeMinute] = array_map('intval', explode(':', $close));
    $openMins = $openHour * 60 + $openMinute; $closeMins = $closeHour * 60 + $closeMinute;
    $start = (int) (ceil($openMins / 60) * 60); $slots = [];
    for ($minute = $start; $minute + 60 <= $closeMins; $minute += 60) $slots[] = sprintf('%02d:00', intdiv($minute, 60));
    if ($date === date('Y-m-d')) {
        $currentMinute = ((int) date('G')) * 60 + (int) date('i');
        $slots = array_values(array_filter($slots, static function (string $slot) use ($currentMinute): bool {
            [$hour, $minute] = array_map('intval', explode(':', $slot));
            return $hour * 60 + $minute > $currentMinute;
        }));
    }
    return $slots;
}

function gym_validate_booking(array $input, array $content): array
{
    $name = gym_string($input, 'fullName', 120);
    if (mb_strlen($name) < 2 || preg_match('/[<>]/', $name)) gym_fail('Enter a valid full name.', 422);
    $phone = gym_string($input, 'phone', 30);
    if (!preg_match('/^\+?[\d\s().-]{7,30}$/', $phone)) gym_fail('Enter a valid phone number.', 422);
    $email = strtolower(gym_string($input, 'email', 254));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) gym_fail('Enter a valid email address.', 422);
    $date = gym_string($input, 'appointmentDate', 10);
    if (!gym_valid_date($date)) gym_fail('Choose today or a future date.', 422);
    $slot = gym_string($input, 'timeSlot', 5);
    if (!preg_match('/^(?:[01]\d|2[0-3]):00$/', $slot) || !in_array($slot, gym_slots($content, $date), true)) gym_fail('Choose an available time during opening hours.', 422);
    $purposes = ['Gym Tour', 'Free Trial', 'Personal Training Consultation', 'Membership Enquiry'];
    $purpose = gym_string($input, 'purpose', 50);
    if (!in_array($purpose, $purposes, true)) gym_fail('Choose a valid appointment purpose.', 422);
    $message = $input['message'] ?? '';
    if (!is_string($message) || mb_strlen($message) > 1000) gym_fail('Keep your message under 1,000 characters.', 422);
    if (($input['privacyConsent'] ?? false) !== true) gym_fail('Please agree to the privacy notice.', 422);
    return ['fullName' => $name, 'phone' => $phone, 'email' => $email, 'appointmentDate' => $date, 'timeSlot' => $slot, 'purpose' => $purpose, 'message' => trim($message)];
}

function gym_clean_content(array $content, int $depth = 0): array
{
    if ($depth > 8 || count($content) > 250) gym_fail('Website content exceeds the allowed limits.', 422);
    if ($depth === 0) {
        $allowed = ['brand', 'hero', 'about', 'plans', 'trainers', 'gallery', 'classes', 'testimonials', 'contact', 'seo'];
        foreach (array_keys($content) as $key) if (!in_array($key, $allowed, true)) gym_fail('Website content contains an unsupported section.', 422);
        foreach (['brand', 'hero', 'about', 'contact', 'seo'] as $required) if (!isset($content[$required]) || !is_array($content[$required])) gym_fail('The ' . $required . ' section is required.', 422);
        foreach (['plans', 'trainers', 'gallery', 'classes', 'testimonials'] as $list) if (!isset($content[$list]) || !is_array($content[$list]) || !array_is_list($content[$list]) || count($content[$list]) > 100) gym_fail('The ' . $list . ' list is invalid or too long.', 422);
        if (!isset($content['contact']['openingHours']) || !is_array($content['contact']['openingHours']) || !array_is_list($content['contact']['openingHours']) || count($content['contact']['openingHours']) !== 7) gym_fail('Provide seven opening-hour entries.', 422);
    }
    $clean = [];
    foreach ($content as $key => $value) {
        if (!is_string($key) || strlen($key) > 64) gym_fail('Website content contains an invalid field.', 422);
        if (is_array($value)) {
            if (count($value) > 100) gym_fail('A website list exceeds the allowed limit.', 422);
            $clean[$key] = array_is_list($value)
                ? array_map(static fn($item) => is_array($item) ? gym_clean_content($item, $depth + 1) : gym_clean_scalar($item), $value)
                : gym_clean_content($value, $depth + 1);
        } else {
            $clean[$key] = gym_clean_scalar($value);
            if (is_string($clean[$key]) && preg_match('/(?:url|link)$/i', $key) && $clean[$key] !== '' && !preg_match('#^(?:https://|/uploads/)#i', $clean[$key])) {
                gym_fail('Website links and images must use a secure URL.', 422);
            }
            if (is_string($clean[$key]) && preg_match('/color$/i', $key) && $clean[$key] !== '' && !preg_match('/^#[0-9a-f]{6}$/i', $clean[$key])) gym_fail('Enter a valid six-digit brand color.', 422);
            if ($key === 'email' && is_string($clean[$key]) && $clean[$key] !== '' && !filter_var($clean[$key], FILTER_VALIDATE_EMAIL)) gym_fail('Enter a valid business email address.', 422);
            if ($key === 'phone' && is_string($clean[$key]) && $clean[$key] !== '' && !preg_match('/^\+?[\d\s().-]{7,30}$/', $clean[$key])) gym_fail('Enter a valid business phone number.', 422);
            if (in_array($key, ['open', 'close'], true) && is_string($clean[$key]) && $clean[$key] !== '' && !preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $clean[$key])) gym_fail('Enter opening hours in 24-hour time.', 422);
        }
    }
    if ($depth === 2 && array_key_exists('day', $clean) && array_key_exists('open', $clean) && array_key_exists('close', $clean)) {
        if (!isset($clean['closed']) || !is_bool($clean['closed']) || !is_string($clean['day'])) gym_fail('Opening hours need a valid day and closed setting.', 422);
        if (!$clean['closed'] && (!is_string($clean['open']) || !is_string($clean['close']) || $clean['open'] === '' || $clean['close'] === '' || $clean['open'] >= $clean['close'])) gym_fail('Each open day needs valid opening and closing times.', 422);
    }
    return $clean;
}

function gym_clean_scalar(mixed $value): mixed
{
    if (is_bool($value) || $value === null) return $value;
    if (!is_string($value) || strlen($value) > 5000) gym_fail('Website text is too long or invalid.', 422);
    return trim($value);
}

function gym_public_booking_shape(array $row): array
{
    return ['id' => (int) $row['id'], 'reference' => (string) $row['reference'], 'fullName' => (string) $row['full_name'], 'phone' => (string) $row['phone'], 'email' => (string) $row['email'], 'appointmentDate' => (string) $row['appointment_date'], 'timeSlot' => (string) $row['time_slot'], 'purpose' => (string) $row['purpose'], 'message' => (string) $row['message'], 'status' => (string) $row['status'], 'adminNotes' => (string) $row['admin_notes'], 'createdAt' => (string) $row['created_at']];
}

function gym_like_escape(string $text): string
{
    return str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $text);
}
