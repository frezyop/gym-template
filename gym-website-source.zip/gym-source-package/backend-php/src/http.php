<?php
declare(strict_types=1);

function gym_json(array $payload, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function gym_fail(string $message, int $status = 400): never
{
    gym_json(['error' => $message], $status);
}

function gym_read_json(): array
{
    $length = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
    if ($length > 350_000) gym_fail('The request is too large.', 413);
    $raw = file_get_contents('php://input');
    if (!is_string($raw) || $raw === '') gym_fail('A request body is required.');
    try {
        $data = json_decode($raw, true, 32, JSON_THROW_ON_ERROR);
    } catch (JsonException) {
        gym_fail('The request body is not valid JSON.');
    }
    if (!is_array($data)) gym_fail('The request body must be an object.');
    return $data;
}

function gym_require_method(string $expected): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== $expected) {
        header('Allow: ' . $expected);
        gym_fail('Method not allowed.', 405);
    }
}

function gym_start_session(array $config): void
{
    $cookieSecure = true;
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_name((string) ($config['session_name'] ?? 'gym_admin_session'));
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => '/',
            'secure' => $cookieSecure,
            'httponly' => true,
            'samesite' => 'None',
        ]);
        session_start();
    }
}

function gym_csrf_token(): string
{
    if (!isset($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function gym_require_csrf(): void
{
    $given = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    $expected = $_SESSION['csrf_token'] ?? '';
    if (!is_string($given) || !is_string($expected) || $expected === '' || !hash_equals($expected, $given)) {
        gym_fail('Your secure session expired. Refresh the page and try again.', 403);
    }
}

function gym_require_admin(): int
{
    $adminId = $_SESSION['admin_id'] ?? null;
    if (!is_int($adminId) && !(is_string($adminId) && ctype_digit($adminId))) gym_fail('Please sign in to continue.', 401);
    return (int) $adminId;
}

function gym_limit(PDO $pdo, array $config, string $kind, string $identity, int $max, int $windowSeconds): void
{
    $key = hash_hmac('sha256', $kind . ':' . $identity, (string) $config['app_key']);
    $cutoff = gmdate('Y-m-d H:i:s', time() - $windowSeconds);
    $pdo->prepare('DELETE FROM request_limits WHERE created_at < :cutoff')->execute(['cutoff' => $cutoff]);
    $pdo->prepare('INSERT INTO request_limits (limit_key) VALUES (:key)')->execute(['key' => $key]);
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM request_limits WHERE limit_key = :key AND created_at >= :cutoff');
    $stmt->execute(['key' => $key, 'cutoff' => $cutoff]);
    if ((int) $stmt->fetchColumn() > $max) gym_fail('Too many attempts. Please wait and try again later.', 429);
}

function gym_remote_identity(): string
{
    // Only trust REMOTE_ADDR; proxy headers are attacker-controlled unless your host config sanitizes them.
    return (string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown');
}
