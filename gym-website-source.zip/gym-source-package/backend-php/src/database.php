<?php
declare(strict_types=1);

function gym_db(array $config): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $db = $config['db'] ?? [];
    foreach (['host', 'port', 'name', 'user', 'password'] as $key) {
        if (!is_string($db[$key] ?? null) || $db[$key] === '' || str_contains($db[$key], 'replace_me')) {
            throw new RuntimeException('The gym database connection is not configured.');
        }
    }
    $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=%s', $db['host'], $db['port'], $db['name'], $db['charset'] ?? 'utf8mb4');
    $pdo = new PDO($dsn, $db['user'], $db['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return $pdo;
}
