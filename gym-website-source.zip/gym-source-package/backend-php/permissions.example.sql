-- Run as the database administrator after creating the gym_app MySQL user.
-- Replace gym_app with the actual database name if different.
GRANT SELECT, INSERT, UPDATE ON gym_app.admins TO 'gym_app'@'localhost';
GRANT SELECT, INSERT, UPDATE ON gym_app.site_settings TO 'gym_app'@'localhost';
GRANT SELECT, INSERT, UPDATE ON gym_app.bookings TO 'gym_app'@'localhost';
GRANT SELECT, INSERT, DELETE ON gym_app.request_limits TO 'gym_app'@'localhost';
