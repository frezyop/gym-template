<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep the gym site's PHP/MySQL service and persistent uploads in `backend-php/` as an independent self-hosted integration; Lovable serves only the frontend, so unconfigured booking/admin operations must stay visibly unavailable rather than simulated.
