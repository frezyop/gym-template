# Gym website source

A responsive, single-page gym website and separate `/admin` owner area. Business content is intentionally unverified starter content; do not publish it as a real gym listing until the owner replaces and confirms it.

## Run the website

Requirements: Node.js 20+ and Bun (or a compatible package manager).

```sh
bun install
bun run dev
```

The public page runs at `/`; the owner area is at `/admin`. Without the separate PHP service configured, booking submission, sign-in, permanent content updates, and uploads remain unavailable and are visibly identified as such.

## Connect the PHP/MySQL service

The website does not host PHP or MySQL. Deploy the independent service in [`backend-php/README.md`](backend-php/README.md), then set the website’s public build variable `VITE_GYM_API_URL` to the HTTPS API base URL (for example `https://api.example.com`) and rebuild/re-publish. The variable is an address, not a credential. Keep database credentials, the app key, and admin password on the PHP host only.

The PHP package includes the MySQL schema, narrow database grants, protected admin setup, booking validation, persistent image uploads, API endpoints, deployment guidance, and a server-side test checklist. The first owner account is created privately through the CLI initializer; there is no public registration.

## Checks

```sh
bunx vitest run
```

The automated tests cover booking date/time rules and route presence. PHP/MySQL integration, login, persistent booking, upload, and conflict handling still require a configured PHP/MySQL host; PHP was not available in the website preview environment.
