import { z } from "zod";

const apiBase = import.meta.env["VITE_GYM_API_URL"]?.trim().replace(/\/$/, "") ?? "";

export const getGymApiBase = () => apiBase;

export const isGymApiConfigured = () => apiBase.length > 0 && /^https?:\/\//i.test(apiBase);

export class GymApiError extends Error {
  constructor(
    message: string,
    readonly status?: number,
  ) {
    super(message);
    this.name = "GymApiError";
  }
}

export async function gymApi<T>(path: string, options: RequestInit = {}): Promise<T> {
  if (!isGymApiConfigured()) throw new GymApiError("The gym website backend is not connected yet.");
  let response: Response;
  try {
    response = await fetch(`${apiBase}${path}`, {
      ...options,
      credentials: "include",
      headers: {
        Accept: "application/json",
        ...(options.body ? { "Content-Type": "application/json" } : {}),
        ...options.headers,
      },
    });
  } catch {
    throw new GymApiError("We could not reach the booking service. Please try again shortly.");
  }
  const body: unknown = await response.json().catch(() => null);
  if (!response.ok) {
    const message = z.object({ error: z.string() }).safeParse(body);
    throw new GymApiError(
      message.success ? message.data.error : "The request could not be completed.",
      response.status,
    );
  }
  return body as T;
}
