import { z } from "zod";
import heroImage from "@/assets/forge-hero.jpg";
import coachImage from "@/assets/trainer-coach.jpg";
import trainingImage from "@/assets/gym-training.jpg";

export type OpeningHour = {
  day: string;
  open: string;
  close: string;
  closed: boolean;
};

export type GymContent = {
  brand: {
    name: string;
    descriptor: string;
    tagline: string;
    logoUrl: string;
    faviconUrl: string;
    accentColor: string;
    instagramUrl: string;
    facebookUrl: string;
    youtubeUrl: string;
  };
  hero: {
    eyebrow: string;
    title: string;
    description: string;
    primaryLabel: string;
    secondaryLabel: string;
    imageUrl: string;
    imageAlt: string;
  };
  about: { title: string; description: string; highlights: string[] };
  plans: Array<{
    name: string;
    price: string;
    period: string;
    description: string;
    features: string[];
  }>;
  trainers: Array<{
    name: string;
    specialty: string;
    bio: string;
    imageUrl: string;
    imageAlt: string;
  }>;
  gallery: Array<{ imageUrl: string; imageAlt: string; caption: string }>;
  classes: Array<{ name: string; description: string; schedule: string; capacity: string }>;
  testimonials: Array<{ name: string; quote: string; memberSince: string }>;
  contact: {
    phone: string;
    whatsapp: string;
    email: string;
    address: string;
    mapsEmbedUrl: string;
    directionsUrl: string;
    privacyUrl: string;
    businessInfoVerified: boolean;
    openingHours: OpeningHour[];
  };
  seo: { title: string; description: string };
};

const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

export const defaultGymContent: GymContent = {
  brand: {
    name: "YOUR GYM",
    descriptor: "STRENGTH CLUB",
    tagline: "A preview brand. Update the business details before launch.",
    logoUrl: "",
    faviconUrl: "",
    accentColor: "#ef4038",
    instagramUrl: "",
    facebookUrl: "",
    youtubeUrl: "",
  },
  hero: {
    eyebrow: "STRENGTH · CONDITIONING · COMMUNITY",
    title: "TRAIN WITH\nINTENT.",
    description:
      "Your gym story starts here. Add your coaching approach, offer and local details from the admin area.",
    primaryLabel: "Explore membership",
    secondaryLabel: "Book a visit",
    imageUrl: heroImage,
    imageAlt: "Strength training floor with a barbell and rack in a dark gym",
  },
  about: {
    title: "A better kind of\nstrong starts here.",
    description:
      "Make this space yours. Tell people what makes your gym different, how you coach, and what members can expect when they walk through the door.",
    highlights: [
      "Your coaching philosophy",
      "Facilities and equipment",
      "The people behind the gym",
    ],
  },
  plans: [],
  trainers: [],
  gallery: [
    {
      imageUrl: trainingImage,
      imageAlt: "Athlete training with ropes in a strength gym",
      caption: "Training floor preview",
    },
    {
      imageUrl: heroImage,
      imageAlt: "Barbell rack in a dark strength training gym",
      caption: "Strength space preview",
    },
    {
      imageUrl: coachImage,
      imageAlt: "Coach in a gym, shown as a generated preview image",
      caption: "Coaching image preview",
    },
  ],
  classes: [],
  testimonials: [],
  contact: {
    phone: "",
    whatsapp: "",
    email: "",
    address: "",
    mapsEmbedUrl: "",
    directionsUrl: "",
    privacyUrl: "",
    businessInfoVerified: false,
    openingHours: days.map((day) => ({ day, open: "", close: "", closed: true })),
  },
  seo: {
    title: "Your Gym | Website preview",
    description:
      "A gym website preview. Replace this title with your real business name and verified details before launch.",
  },
};

function mergeObjects<T>(base: T, override: unknown): T {
  if (!override || typeof override !== "object" || Array.isArray(override)) return base;
  const result = { ...(base as Record<string, unknown>) };
  for (const [key, value] of Object.entries(override)) {
    const current = result[key];
    if (Array.isArray(value)) result[key] = value;
    else if (
      value &&
      typeof value === "object" &&
      current &&
      typeof current === "object" &&
      !Array.isArray(current)
    ) {
      result[key] = mergeObjects(current, value);
    } else if (typeof value === "string" || typeof value === "boolean") {
      result[key] = value;
    }
  }
  return result as T;
}

export function mergeGymContent(override: unknown): GymContent {
  return mergeObjects(defaultGymContent, override);
}

const phoneSchema = z
  .string()
  .trim()
  .min(7, "Enter a valid phone number.")
  .max(30)
  .regex(/^\+?[\d\s().-]{7,30}$/, "Enter a valid phone number.");

export function isBookingDateAllowed(date: string, today = new Date()): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return false;
  const [year = 0, month = 0, day = 0] = date.split("-").map(Number);
  const parsed = new Date(year, month - 1, day);
  if (parsed.getFullYear() !== year || parsed.getMonth() !== month - 1 || parsed.getDate() !== day)
    return false;
  const localToday = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
  return date >= localToday;
}

export const bookingSchema = z.object({
  fullName: z.string().trim().min(2, "Enter your full name.").max(120),
  phone: phoneSchema,
  email: z.string().trim().email("Enter a valid email address.").max(254),
  appointmentDate: z
    .string()
    .refine((date) => isBookingDateAllowed(date), "Choose today or a future date."),
  timeSlot: z.string().regex(/^([01]\d|2[0-3]):00$/, "Choose an available time slot."),
  purpose: z.enum([
    "Gym Tour",
    "Free Trial",
    "Personal Training Consultation",
    "Membership Enquiry",
  ]),
  message: z
    .string()
    .trim()
    .max(1000, "Keep your message under 1,000 characters.")
    .optional()
    .default(""),
  privacyConsent: z.boolean().refine((consent) => consent, "Please agree to the privacy notice."),
});

export type BookingInput = z.infer<typeof bookingSchema>;

export function getAvailableSlots(
  date: string,
  openingHours: OpeningHour[],
  blockedSlots: string[] = [],
  today = new Date(),
): string[] {
  if (!isBookingDateAllowed(date, today)) return [];
  const dateValue = new Date(`${date}T00:00:00`);
  const weekday = dateValue.getDay() === 0 ? 6 : dateValue.getDay() - 1;
  const hours = openingHours[weekday];
  if (
    !hours ||
    hours.closed ||
    !/^([01]\d|2[0-3]):[0-5]\d$/.test(hours.open) ||
    !/^([01]\d|2[0-3]):[0-5]\d$/.test(hours.close)
  )
    return [];
  const [openHour = 0, openMinute = 0] = hours.open.split(":").map(Number);
  const [closeHour = 0, closeMinute = 0] = hours.close.split(":").map(Number);
  const open = openHour * 60 + openMinute;
  const close = closeHour * 60 + closeMinute;
  const blocked = new Set(blockedSlots);
  const slots: string[] = [];
  for (let start = Math.ceil(open / 60) * 60; start + 60 <= close; start += 60) {
    const slot = `${String(Math.floor(start / 60)).padStart(2, "0")}:00`;
    if (!blocked.has(slot)) slots.push(slot);
  }
  return slots;
}
