import { createFileRoute } from "@tanstack/react-router";
import { GymAdmin } from "@/components/gym-admin";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Gym admin | Your Gym" },
      { name: "description", content: "Private gym administration and booking management." },
      { property: "og:title", content: "Gym admin | Your Gym" },
      { property: "og:description", content: "Private gym administration and booking management." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: GymAdmin,
});
