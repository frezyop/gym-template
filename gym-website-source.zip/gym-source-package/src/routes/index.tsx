import { createFileRoute } from "@tanstack/react-router";
import { GymSite } from "@/components/gym-site";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Your Gym | Website preview" },
      {
        name: "description",
        content:
          "A strength-focused gym website preview. Replace the sample details with verified business information before publishing.",
      },
      { property: "og:title", content: "Your Gym | Website preview" },
      {
        property: "og:description",
        content:
          "Explore the gym website preview and customize its business information before publishing.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: GymSite,
});
