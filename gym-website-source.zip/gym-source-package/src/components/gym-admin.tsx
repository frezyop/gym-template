import { useCallback, useEffect, useMemo, useState, type ChangeEvent, type FormEvent } from "react";
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  CalendarDays,
  Check,
  ChevronDown,
  Clock3,
  Dumbbell,
  ImagePlus,
  LogOut,
  Menu,
  MessageSquareText,
  Pencil,
  Plus,
  Search,
  Settings2,
  ShieldCheck,
  Trash2,
  Users,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { defaultGymContent, mergeGymContent, type GymContent } from "@/lib/gym-content";
import { getGymApiBase, gymApi, isGymApiConfigured } from "@/lib/gym-api";

type Booking = {
  id: number;
  reference: string;
  fullName: string;
  phone: string;
  email: string;
  appointmentDate: string;
  timeSlot: string;
  purpose: string;
  message: string;
  status: "Pending" | "Accepted" | "Rejected" | "Cancelled" | "Completed";
  adminNotes: string;
  createdAt: string;
};

type Dashboard = { counts: Record<Booking["status"], number>; bookings: Booking[] };
type Tab =
  | "overview"
  | "appointments"
  | "website"
  | "plans"
  | "trainers"
  | "gallery"
  | "classes"
  | "testimonials";
type CollectionKey = "plans" | "trainers" | "gallery" | "classes" | "testimonials";
type CollectionItem = Record<string, string | string[]>;

const tabs: Array<{ id: Tab; label: string; icon: typeof CalendarDays }> = [
  { id: "overview", label: "Overview", icon: Settings2 },
  { id: "appointments", label: "Appointments", icon: CalendarDays },
  { id: "website", label: "Website details", icon: Pencil },
  { id: "plans", label: "Memberships", icon: Dumbbell },
  { id: "trainers", label: "Trainers", icon: Users },
  { id: "gallery", label: "Gallery", icon: ImagePlus },
  { id: "classes", label: "Classes", icon: Clock3 },
  { id: "testimonials", label: "Testimonials", icon: MessageSquareText },
];

const collectionFields: Record<
  CollectionKey,
  Array<{ key: string; label: string; multiline?: boolean; image?: boolean }>
> = {
  plans: [
    { key: "name", label: "Plan name" },
    { key: "price", label: "Price" },
    { key: "period", label: "Billing period" },
    { key: "description", label: "Description", multiline: true },
    { key: "features", label: "Included benefits (one per line)", multiline: true },
  ],
  trainers: [
    { key: "name", label: "Trainer name" },
    { key: "specialty", label: "Specialty" },
    { key: "bio", label: "Biography", multiline: true },
    { key: "imageUrl", label: "Photo URL", image: true },
    { key: "imageAlt", label: "Photo description" },
  ],
  gallery: [
    { key: "caption", label: "Image caption" },
    { key: "imageUrl", label: "Image URL", image: true },
    { key: "imageAlt", label: "Image description" },
  ],
  classes: [
    { key: "name", label: "Class name" },
    { key: "description", label: "Description", multiline: true },
    { key: "schedule", label: "Weekly schedule" },
    { key: "capacity", label: "Availability note" },
  ],
  testimonials: [
    { key: "name", label: "Member name" },
    { key: "quote", label: "Member story", multiline: true },
    { key: "memberSince", label: "Member since" },
  ],
};

const blankItems: Record<CollectionKey, CollectionItem> = {
  plans: { name: "", price: "", period: "/ month", description: "", features: [] },
  trainers: { name: "", specialty: "", bio: "", imageUrl: "", imageAlt: "" },
  gallery: { caption: "", imageUrl: "", imageAlt: "" },
  classes: { name: "", description: "", schedule: "", capacity: "" },
  testimonials: { name: "", quote: "", memberSince: "" },
};

const tabTitle: Record<Tab, string> = {
  overview: "Today at the gym",
  appointments: "Appointment requests",
  website: "Website details",
  plans: "Membership plans",
  trainers: "Trainer profiles",
  gallery: "Gallery",
  classes: "Classes & sessions",
  testimonials: "Member stories",
};

const csrfPath = "/auth/csrf";

function setPath<T>(value: T, path: string, next: unknown): T {
  const result = structuredClone(value) as Record<string, unknown>;
  const parts = path.split(".");
  let cursor = result;
  for (const part of parts.slice(0, -1)) {
    const child = cursor[part];
    if (!child || typeof child !== "object") return value;
    cursor = child as Record<string, unknown>;
  }
  cursor[parts.at(-1) ?? ""] = next;
  return result as T;
}

function DateTime({ value }: { value: string }) {
  const date = new Date(value);
  return (
    <>
      {Number.isNaN(date.getTime())
        ? value
        : date.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" })}
    </>
  );
}

function StatusPill({ status }: { status: Booking["status"] }) {
  return (
    <span className={`status-pill status-${status.toLowerCase()}`}>
      <span />
      {status}
    </span>
  );
}

export function GymAdmin() {
  const [tab, setTab] = useState<Tab>("overview");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [csrf, setCsrf] = useState("");
  const [authenticated, setAuthenticated] = useState(false);
  const [checking, setChecking] = useState(true);
  const [login, setLogin] = useState({ username: "", password: "" });
  const [loginError, setLoginError] = useState("");
  const [site, setSite] = useState<GymContent>(defaultGymContent);
  const [dashboard, setDashboard] = useState<Dashboard | null>(null);
  const [saveState, setSaveState] = useState("");
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("All status");
  const [dateFilter, setDateFilter] = useState("");
  const [activeBooking, setActiveBooking] = useState<number | null>(null);
  const [mobileMenuBusy, setMobileMenuBusy] = useState(false);

  const authHeaders = useMemo(() => (csrf ? { "X-CSRF-Token": csrf } : {}), [csrf]);

  const loadDashboard = useCallback(async () => {
    const filters = new URLSearchParams();
    if (query.trim()) filters.set("search", query.trim());
    if (statusFilter !== "All status") filters.set("status", statusFilter);
    if (dateFilter) filters.set("date", dateFilter);
    const suffix = filters.size ? `?${filters.toString()}` : "";
    const result = await gymApi<Dashboard>(`/admin/bookings${suffix}`);
    setDashboard(result);
  }, [query, statusFilter, dateFilter]);

  const loadSite = useCallback(async () => {
    const result = await gymApi<{ content: unknown }>("/admin/site");
    setSite(mergeGymContent(result.content));
  }, []);

  const refreshAdmin = useCallback(async () => {
    try {
      const response = await gymApi<{ authenticated: boolean }>("/auth/session");
      if (response.authenticated) {
        setAuthenticated(true);
        const [csrfResponse] = await Promise.all([
          gymApi<{ csrfToken: string }>(csrfPath),
          loadDashboard(),
          loadSite(),
        ]);
        setCsrf(csrfResponse.csrfToken);
      } else {
        setAuthenticated(false);
      }
    } catch {
      setAuthenticated(false);
    } finally {
      setChecking(false);
    }
  }, [loadDashboard, loadSite]);

  useEffect(() => {
    void refreshAdmin();
  }, [refreshAdmin]);

  useEffect(() => {
    if (!authenticated || !isGymApiConfigured()) return;
    const timer = window.setInterval(() => {
      void loadDashboard().catch(() => undefined);
    }, 45_000);
    return () => window.clearInterval(timer);
  }, [authenticated, loadDashboard]);

  useEffect(() => {
    if (!authenticated || tab !== "appointments") return;
    const timer = window.setTimeout(() => {
      void loadDashboard().catch(() => undefined);
    }, 250);
    return () => window.clearTimeout(timer);
  }, [authenticated, tab, loadDashboard]);

  async function signIn(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoginError("");
    setMobileMenuBusy(true);
    try {
      const tokenResponse = await gymApi<{ csrfToken: string }>(csrfPath);
      const result = await gymApi<{ authenticated: boolean; csrfToken: string }>("/auth/login", {
        method: "POST",
        headers: { "X-CSRF-Token": tokenResponse.csrfToken },
        body: JSON.stringify(login),
      });
      setCsrf(result.csrfToken);
      setAuthenticated(true);
      const [bookings, page] = await Promise.all([
        gymApi<Dashboard>("/admin/bookings"),
        gymApi<{ content: unknown }>("/admin/site"),
      ]);
      setDashboard(bookings);
      setSite(mergeGymContent(page.content));
    } catch (error) {
      setLoginError(
        error instanceof Error
          ? error.message
          : "Sign-in failed. Check your details and try again.",
      );
    } finally {
      setMobileMenuBusy(false);
    }
  }

  async function signOut() {
    try {
      await gymApi<{ signedOut: boolean }>("/auth/logout", {
        method: "POST",
        headers: authHeaders,
        body: JSON.stringify({}),
      });
    } catch {
      /* Clearing the local admin view remains safe when the service is offline. */
    }
    setAuthenticated(false);
    setCsrf("");
    setDashboard(null);
    setLogin({ username: "", password: "" });
  }

  async function saveSite(next: GymContent) {
    setSaveState("Saving…");
    try {
      await gymApi<{ saved: boolean }>("/admin/site", {
        method: "PUT",
        headers: authHeaders,
        body: JSON.stringify({ content: next }),
      });
      setSite(next);
      setSaveState("Saved. The public website is updated.");
      window.setTimeout(() => setSaveState(""), 4500);
    } catch (error) {
      setSaveState(error instanceof Error ? error.message : "Changes could not be saved.");
    }
  }

  function previewSite(content: GymContent) {
    const previewWindow = window.open("/?preview=gym", "gym-site-preview");
    if (!previewWindow) {
      setSaveState("Allow pop-ups to preview this draft.");
      return;
    }
    const sendPreview = (event: MessageEvent<unknown>) => {
      if (event.origin !== window.location.origin || event.source !== previewWindow) return;
      if (
        event.data &&
        typeof event.data === "object" &&
        "type" in event.data &&
        event.data.type === "gym-preview-ready"
      ) {
        previewWindow.postMessage({ type: "gym-preview-content", content }, window.location.origin);
        window.removeEventListener("message", sendPreview);
      }
    };
    window.addEventListener("message", sendPreview);
    window.setTimeout(() => window.removeEventListener("message", sendPreview), 15_000);
  }

  async function changeBooking(id: number, payload: Record<string, string>) {
    try {
      await gymApi<{ booking: Booking }>(`/admin/bookings/${id}`, {
        method: "PATCH",
        headers: authHeaders,
        body: JSON.stringify(payload),
      });
      await loadDashboard();
    } catch (error) {
      setSaveState(error instanceof Error ? error.message : "Booking change could not be saved.");
    }
  }

  const filteredBookings = dashboard?.bookings ?? [];

  function updateContent(path: string, value: unknown) {
    setSite((current) => setPath(current, path, value));
    setSaveState("Unsaved changes");
  }

  if (checking)
    return (
      <div className="admin-loading">
        <span className="admin-loader" />
        <p>Opening the secure admin area…</p>
      </div>
    );

  if (!isGymApiConfigured()) {
    return (
      <main className="admin-setup-screen">
        <div className="admin-login-brand">
          <span className="admin-brand-icon">
            <Dumbbell size={21} />
          </span>
          <span>
            GYM ADMIN<span>PRIVATE AREA</span>
          </span>
        </div>
        <div className="admin-setup-card">
          <p className="eyebrow">
            <span className="eyebrow-mark" />
            BACKEND SETUP REQUIRED
          </p>
          <h1>Connect your gym’s secure service.</h1>
          <p>
            The admin area and online bookings need a hosted PHP/MySQL service. This preview has no
            connected service, so sign-in, permanent edits, image uploads, and booking requests are
            intentionally unavailable.
          </p>
          <ol>
            <li>Deploy the included PHP API to your PHP 8.1+ web host.</li>
            <li>Set its MySQL connection, allowed website URL, and secure cookie settings.</li>
            <li>
              Set <code>VITE_GYM_API_URL</code> to the API’s public base address and publish the
              website.
            </li>
          </ol>
          <a className="text-link" href="/">
            Return to public website <ArrowLeft size={17} />
          </a>
        </div>
      </main>
    );
  }

  if (!authenticated) {
    return (
      <main className="admin-login-screen">
        <div className="admin-login-top">
          <a href="/" className="admin-back-link">
            <ArrowLeft size={17} />
            Public website
          </a>
          <span>SECURE ADMIN ACCESS</span>
        </div>
        <div className="admin-login-card">
          <div className="admin-login-brand">
            <span className="admin-brand-icon">
              <Dumbbell size={21} />
            </span>
            <span>
              GYM ADMIN<span>PRIVATE AREA</span>
            </span>
          </div>
          <p className="eyebrow">
            <span className="eyebrow-mark" />
            OWNER SIGN IN
          </p>
          <h1>Welcome back.</h1>
          <p>Sign in with the account created by the server administrator.</p>
          <form className="admin-login-form" onSubmit={signIn}>
            <label>
              Email
              <input
                type="email"
                autoComplete="username"
                required
                maxLength={254}
                value={login.username}
                onChange={(event) =>
                  setLogin((state) => ({ ...state, username: event.target.value }))
                }
              />
            </label>
            <label>
              Password
              <input
                type="password"
                autoComplete="current-password"
                required
                maxLength={200}
                value={login.password}
                onChange={(event) =>
                  setLogin((state) => ({ ...state, password: event.target.value }))
                }
              />
            </label>
            {loginError && (
              <p className="admin-error" role="alert">
                {loginError}
              </p>
            )}
            <Button
              className="gym-button gym-button-red admin-signin-button"
              type="submit"
              disabled={mobileMenuBusy}
            >
              {mobileMenuBusy ? "Signing in…" : "Sign in securely"}
              <ArrowRight size={17} />
            </Button>
          </form>
          <p className="admin-login-foot">
            <ShieldCheck size={16} />
            No public registration · Protected by the server
          </p>
        </div>
        <p className="admin-login-copyright">{defaultGymContent.brand.name} · OWNER TOOLS</p>
      </main>
    );
  }

  function goTo(next: Tab) {
    setTab(next);
    setMobileNavOpen(false);
  }

  return (
    <main className="admin-app">
      <header className="admin-topbar">
        <a href="/" className="admin-app-brand">
          <span className="admin-brand-icon">
            <Dumbbell size={20} />
          </span>
          <span>
            {site.brand.name}
            <small>GYM ADMIN</small>
          </span>
        </a>
        <div className="admin-topbar-right">
          <span className="admin-user">
            <span className="admin-user-dot" />
            Owner
          </span>
          <Button variant="ghost" size="sm" className="admin-logout" onClick={signOut}>
            <LogOut size={16} />
            Sign out
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="admin-mobile-menu"
            onClick={() => setMobileNavOpen((open) => !open)}
            aria-label="Toggle admin navigation"
          >
            {mobileNavOpen ? <X /> : <Menu />}
          </Button>
        </div>
      </header>
      <div className="admin-layout">
        <aside className={`admin-sidebar ${mobileNavOpen ? "admin-sidebar-open" : ""}`}>
          <span className="admin-nav-title">WORKSPACE</span>
          {tabs.map(({ id, label, icon: Icon }) => (
            <button
              type="button"
              key={id}
              className={`admin-nav-link ${tab === id ? "admin-nav-link-active" : ""}`}
              onClick={() => goTo(id)}
            >
              <Icon size={17} />
              {label}
              {id === "appointments" && (dashboard?.counts.Pending ?? 0) > 0 && (
                <span className="nav-count">{dashboard?.counts.Pending}</span>
              )}
            </button>
          ))}
          <div className="admin-sidebar-bottom">
            <span className="admin-sidebar-status">
              <span />
              {site.contact.businessInfoVerified
                ? "Business details confirmed"
                : "Website preview mode"}
            </span>
            <a href="/" target="_blank" rel="noreferrer">
              View public website <ArrowUpRightIcon />
            </a>
          </div>
        </aside>
        <section className="admin-main">
          <div className="admin-page-heading">
            <div>
              <p className="admin-breadcrumb">
                WORKSPACE <span>/</span> {tab.toUpperCase()}
              </p>
              <h1>{tabTitle[tab]}</h1>
            </div>
            <div className="admin-heading-tools">
              {saveState && (
                <span
                  className={`admin-save-message ${saveState.startsWith("Saved") ? "save-success" : saveState === "Unsaved changes" ? "save-unsaved" : ""}`}
                  role="status"
                >
                  {saveState.startsWith("Saved") && <Check size={14} />}
                  {saveState}
                </span>
              )}
              {tab === "appointments" && (
                <Button
                  variant="outline"
                  className="admin-refresh-button"
                  onClick={() => void loadDashboard()}
                >
                  <ArrowDown size={15} />
                  Refresh
                </Button>
              )}
              {(tab === "website" ||
                tab === "plans" ||
                tab === "trainers" ||
                tab === "gallery" ||
                tab === "classes" ||
                tab === "testimonials") && (
                <Button
                  variant="outline"
                  className="admin-refresh-button"
                  onClick={() => previewSite(site)}
                >
                  Preview draft
                </Button>
              )}
              {tab === "website" && (
                <Button
                  className="gym-button gym-button-red admin-save-button"
                  onClick={() => void saveSite(site)}
                >
                  Save changes <Check size={16} />
                </Button>
              )}
            </div>
          </div>
          {tab === "overview" && (
            <Overview
              dashboard={dashboard}
              onOpen={(id) => {
                goTo("appointments");
                setActiveBooking(id);
              }}
            />
          )}
          {tab === "appointments" && (
            <Appointments
              dashboard={dashboard}
              bookings={filteredBookings}
              query={query}
              setQuery={setQuery}
              statusFilter={statusFilter}
              setStatusFilter={setStatusFilter}
              dateFilter={dateFilter}
              setDateFilter={setDateFilter}
              activeBooking={activeBooking}
              setActiveBooking={setActiveBooking}
              changeBooking={changeBooking}
            />
          )}
          {tab === "website" && (
            <WebsiteEditor
              content={site}
              updateContent={updateContent}
              saveSite={saveSite}
              csrf={csrf}
            />
          )}
          {(tab === "plans" ||
            tab === "trainers" ||
            tab === "gallery" ||
            tab === "classes" ||
            tab === "testimonials") && (
            <CollectionEditor
              type={tab}
              content={site}
              updateContent={updateContent}
              saveSite={saveSite}
              previewSite={previewSite}
              csrf={csrf}
            />
          )}
        </section>
      </div>
    </main>
  );
}

function ArrowUpRightIcon() {
  return <ArrowRight size={15} aria-hidden="true" />;
}

function Overview({
  dashboard,
  onOpen,
}: {
  dashboard: Dashboard | null;
  onOpen: (id: number) => void;
}) {
  const counts = dashboard?.counts ?? {
    Pending: 0,
    Accepted: 0,
    Rejected: 0,
    Cancelled: 0,
    Completed: 0,
  };
  const total = Object.values(counts).reduce((sum, value) => sum + value, 0);
  return (
    <div className="overview-content">
      <div className="stats-grid">
        <article className="stat-card stat-card-red">
          <span>PENDING REQUESTS</span>
          <strong>{counts.Pending}</strong>
          <p>Waiting for your review</p>
          <CalendarDays size={21} />
        </article>
        <article className="stat-card">
          <span>ACCEPTED</span>
          <strong>{counts.Accepted}</strong>
          <p>Confirmed appointments</p>
          <Check size={21} />
        </article>
        <article className="stat-card">
          <span>COMPLETED</span>
          <strong>{counts.Completed}</strong>
          <p>Visits completed</p>
          <Users size={21} />
        </article>
        <article className="stat-card">
          <span>ALL BOOKINGS</span>
          <strong>{total}</strong>
          <p>Lifetime requests</p>
          <Clock3 size={21} />
        </article>
      </div>
      <section className="admin-table-section">
        <div className="admin-section-title">
          <div>
            <p className="admin-kicker">LATEST ACTIVITY</p>
            <h2>Recent appointment requests</h2>
          </div>
          <Button variant="ghost" className="text-link-button" onClick={() => onOpen(0)}>
            View all <ArrowRight size={16} />
          </Button>
        </div>
        {dashboard?.bookings.length ? (
          <div className="admin-booking-list">
            {dashboard.bookings.slice(0, 5).map((booking) => (
              <button
                className="admin-booking-row"
                key={booking.id}
                onClick={() => onOpen(booking.id)}
              >
                <span className="booking-avatar">{booking.fullName.slice(0, 1).toUpperCase()}</span>
                <span className="booking-row-main">
                  <strong>{booking.fullName}</strong>
                  <small>
                    {booking.purpose} · {booking.appointmentDate} at {booking.timeSlot}
                  </small>
                </span>
                <StatusPill status={booking.status} />
                <ArrowRight size={16} />
              </button>
            ))}
          </div>
        ) : (
          <div className="admin-empty">
            <CalendarDays size={23} />
            <strong>No appointment requests yet</strong>
            <p>New requests will appear here after the booking service is connected.</p>
          </div>
        )}
      </section>
      <div className="admin-note-band">
        <ShieldCheck size={20} />
        <p>
          Customer information is only available after owner sign-in and is protected by the hosted
          service.
        </p>
      </div>
    </div>
  );
}

function Appointments(props: {
  dashboard: Dashboard | null;
  bookings: Booking[];
  query: string;
  setQuery: (value: string) => void;
  statusFilter: string;
  setStatusFilter: (value: string) => void;
  dateFilter: string;
  setDateFilter: (value: string) => void;
  activeBooking: number | null;
  setActiveBooking: (value: number | null) => void;
  changeBooking: (id: number, payload: Record<string, string>) => Promise<void>;
}) {
  return (
    <div className="appointments-content">
      <div className="appointment-filter-bar">
        <label className="search-field">
          <Search size={17} />
          <Input
            value={props.query}
            onChange={(event) => props.setQuery(event.target.value)}
            placeholder="Search name, phone, email, reference"
            aria-label="Search appointments"
          />
        </label>
        <label className="filter-select-label">
          <span>Status</span>
          <select
            value={props.statusFilter}
            onChange={(event) => props.setStatusFilter(event.target.value)}
          >
            <option>All status</option>
            <option>Pending</option>
            <option>Accepted</option>
            <option>Rejected</option>
            <option>Cancelled</option>
            <option>Completed</option>
          </select>
          <ChevronDown size={15} />
        </label>
        <label className="date-filter">
          <span>Date</span>
          <Input
            type="date"
            value={props.dateFilter}
            onChange={(event) => props.setDateFilter(event.target.value)}
            aria-label="Filter by appointment date"
          />
        </label>
        {props.dateFilter && (
          <Button
            variant="ghost"
            size="icon"
            onClick={() => props.setDateFilter("")}
            aria-label="Clear date filter"
          >
            <X size={17} />
          </Button>
        )}
      </div>
      {props.bookings.length ? (
        <div className="booking-admin-cards">
          {props.bookings.map((booking) => (
            <BookingCard
              key={booking.id}
              booking={booking}
              active={props.activeBooking === booking.id}
              onToggle={() =>
                props.setActiveBooking(props.activeBooking === booking.id ? null : booking.id)
              }
              onChange={(payload) => props.changeBooking(booking.id, payload)}
            />
          ))}
        </div>
      ) : (
        <div className="admin-empty appointments-empty">
          <CalendarDays size={26} />
          <strong>
            {props.dashboard?.bookings.length
              ? "No requests match those filters"
              : "No appointment requests"}
          </strong>
          <p>Bookings will appear here when the online form is connected to your PHP service.</p>
        </div>
      )}
    </div>
  );
}

function BookingCard({
  booking,
  active,
  onToggle,
  onChange,
}: {
  booking: Booking;
  active: boolean;
  onToggle: () => void;
  onChange: (payload: Record<string, string>) => void;
}) {
  const [note, setNote] = useState(booking.adminNotes ?? "");
  const [date, setDate] = useState(booking.appointmentDate);
  const [time, setTime] = useState(booking.timeSlot);
  useEffect(() => {
    setNote(booking.adminNotes ?? "");
    setDate(booking.appointmentDate);
    setTime(booking.timeSlot);
  }, [booking]);
  return (
    <article className="booking-admin-card">
      <button className="booking-card-summary" onClick={onToggle} aria-expanded={active}>
        <span className="booking-avatar">{booking.fullName.slice(0, 1).toUpperCase()}</span>
        <span className="booking-summary-main">
          <strong>{booking.fullName}</strong>
          <small>
            {booking.purpose} · {booking.appointmentDate} · {booking.timeSlot}
          </small>
          <small className="booking-reference">REF {booking.reference}</small>
        </span>
        <StatusPill status={booking.status} />
        <ChevronDown size={18} className={active ? "chevron-rotated" : ""} />
      </button>
      {active && (
        <div className="booking-card-details">
          <div className="booking-contact-line">
            <a href={`tel:${booking.phone}`}>{booking.phone || "No phone provided"}</a>
            <a href={`mailto:${booking.email}`}>{booking.email}</a>
            <span>
              Submitted <DateTime value={booking.createdAt} />
            </span>
          </div>
          {booking.message && (
            <div className="customer-message">
              <span>CUSTOMER MESSAGE</span>
              <p>{booking.message}</p>
            </div>
          )}
          <div className="booking-management">
            <label>
              Private admin notes
              <Textarea
                rows={2}
                maxLength={2000}
                value={note}
                onChange={(event) => setNote(event.target.value)}
                placeholder="Only visible to admins"
              />
            </label>
            <Button variant="outline" size="sm" onClick={() => onChange({ adminNotes: note })}>
              Save note
            </Button>
            <div className="reschedule-fields">
              <label>
                Date
                <Input
                  type="date"
                  min={new Date().toISOString().slice(0, 10)}
                  value={date}
                  onChange={(event) => setDate(event.target.value)}
                />
              </label>
              <label>
                Time
                <select value={time} onChange={(event) => setTime(event.target.value)}>
                  {Array.from(
                    { length: 16 },
                    (_, index) => `${String(index + 6).padStart(2, "0")}:00`,
                  ).map((slot) => (
                    <option key={slot}>{slot}</option>
                  ))}
                </select>
              </label>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onChange({ appointmentDate: date, timeSlot: time })}
              >
                Reschedule
              </Button>
            </div>
            <div className="booking-actions">
              {booking.status === "Pending" && (
                <>
                  <Button
                    className="action-accept"
                    size="sm"
                    onClick={() => onChange({ status: "Accepted" })}
                  >
                    <Check size={15} />
                    Accept
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onChange({ status: "Rejected" })}
                  >
                    <X size={15} />
                    Reject
                  </Button>
                </>
              )}
              {booking.status === "Accepted" && (
                <>
                  <Button
                    className="action-accept"
                    size="sm"
                    onClick={() => onChange({ status: "Completed" })}
                  >
                    <Check size={15} />
                    Complete
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onChange({ status: "Cancelled" })}
                  >
                    Cancel
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </article>
  );
}

function TextField({
  label,
  value,
  onChange,
  multiline = false,
  maxLength = 2000,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  multiline?: boolean;
  maxLength?: number;
  placeholder?: string;
}) {
  return (
    <label className="editor-field">
      <span>{label}</span>
      {multiline ? (
        <Textarea
          rows={4}
          maxLength={maxLength}
          value={value}
          onChange={(event) => onChange(event.target.value)}
          placeholder={placeholder}
        />
      ) : (
        <Input
          value={value}
          maxLength={maxLength}
          onChange={(event) => onChange(event.target.value)}
          placeholder={placeholder}
        />
      )}
    </label>
  );
}

function ImageUpload({
  label,
  csrf,
  onUploaded,
}: {
  label: string;
  csrf: string;
  onUploaded: (url: string) => void;
}) {
  const [uploading, setUploading] = useState(false);
  return (
    <label className="upload-control upload-control-editor">
      <ImagePlus size={16} />
      {uploading ? "Uploading…" : label}
      <input
        type="file"
        accept="image/jpeg,image/png,image/webp"
        disabled={uploading}
        onChange={(event: ChangeEvent<HTMLInputElement>) => {
          const file = event.target.files?.[0];
          event.target.value = "";
          if (!file) return;
          const payload = new FormData();
          payload.append("image", file);
          setUploading(true);
          fetch(`${getGymApiBase()}/admin/uploads`, {
            method: "POST",
            credentials: "include",
            headers: { "X-CSRF-Token": csrf, Accept: "application/json" },
            body: payload,
          })
            .then(async (response) => {
              const body = (await response.json()) as { url?: string; error?: string };
              if (!response.ok || !body.url) throw new Error(body.error ?? "Image upload failed.");
              onUploaded(body.url.startsWith("http") ? body.url : `${getGymApiBase()}${body.url}`);
            })
            .catch((error: unknown) =>
              window.alert(error instanceof Error ? error.message : "Image upload failed."),
            )
            .finally(() => setUploading(false));
        }}
      />
    </label>
  );
}

function WebsiteEditor({
  content,
  updateContent,
  saveSite,
  csrf,
}: {
  content: GymContent;
  updateContent: (path: string, value: unknown) => void;
  saveSite: (content: GymContent) => Promise<void>;
  csrf: string;
}) {
  return (
    <div className="website-editor">
      <div className="editor-intro">
        <p>Manage the information visitors see across the public website.</p>
        <span>
          <ShieldCheck size={16} />
          Updates go live when saved
        </span>
      </div>
      <section className="editor-panel">
        <div className="editor-panel-heading">
          <span>01</span>
          <div>
            <h2>Brand & introduction</h2>
            <p>Gym identity and opening message.</p>
          </div>
        </div>
        <div className="editor-fields-grid">
          <TextField
            label="Gym name"
            value={content.brand.name}
            onChange={(value) => updateContent("brand.name", value)}
          />
          <TextField
            label="Descriptor"
            value={content.brand.descriptor}
            onChange={(value) => updateContent("brand.descriptor", value)}
          />
          <TextField
            label="Tagline"
            value={content.brand.tagline}
            onChange={(value) => updateContent("brand.tagline", value)}
          />
          <TextField
            label="Brand accent color (hex)"
            value={content.brand.accentColor}
            onChange={(value) => updateContent("brand.accentColor", value)}
          />
          <TextField
            label="Instagram profile URL"
            value={content.brand.instagramUrl}
            onChange={(value) => updateContent("brand.instagramUrl", value)}
          />
          <TextField
            label="Facebook page URL"
            value={content.brand.facebookUrl}
            onChange={(value) => updateContent("brand.facebookUrl", value)}
          />
          <TextField
            label="YouTube channel URL"
            value={content.brand.youtubeUrl}
            onChange={(value) => updateContent("brand.youtubeUrl", value)}
          />
          <TextField
            label="Logo URL"
            value={content.brand.logoUrl}
            onChange={(value) => updateContent("brand.logoUrl", value)}
          />
          <ImageUpload
            label="Upload logo"
            csrf={csrf}
            onUploaded={(url) => updateContent("brand.logoUrl", url)}
          />
          <TextField
            label="Favicon URL"
            value={content.brand.faviconUrl}
            onChange={(value) => updateContent("brand.faviconUrl", value)}
          />
          <ImageUpload
            label="Upload favicon"
            csrf={csrf}
            onUploaded={(url) => updateContent("brand.faviconUrl", url)}
          />
          <TextField
            label="Hero eyebrow"
            value={content.hero.eyebrow}
            onChange={(value) => updateContent("hero.eyebrow", value)}
          />
          <TextField
            label="Hero heading (line breaks supported)"
            value={content.hero.title}
            multiline
            onChange={(value) => updateContent("hero.title", value)}
          />
          <TextField
            label="Hero description"
            value={content.hero.description}
            multiline
            onChange={(value) => updateContent("hero.description", value)}
          />
          <TextField
            label="Hero photo URL"
            value={content.hero.imageUrl}
            onChange={(value) => updateContent("hero.imageUrl", value)}
          />
          <ImageUpload
            label="Upload hero photo"
            csrf={csrf}
            onUploaded={(url) => updateContent("hero.imageUrl", url)}
          />
          <TextField
            label="Hero photo description"
            value={content.hero.imageAlt}
            onChange={(value) => updateContent("hero.imageAlt", value)}
          />
          <TextField
            label="Primary button label"
            value={content.hero.primaryLabel}
            onChange={(value) => updateContent("hero.primaryLabel", value)}
          />
          <TextField
            label="Secondary button label"
            value={content.hero.secondaryLabel}
            onChange={(value) => updateContent("hero.secondaryLabel", value)}
          />
        </div>
      </section>
      <section className="editor-panel">
        <div className="editor-panel-heading">
          <span>02</span>
          <div>
            <h2>About your gym</h2>
            <p>Describe the space, team and approach.</p>
          </div>
        </div>
        <div className="editor-fields-grid">
          <TextField
            label="Section heading"
            value={content.about.title}
            multiline
            onChange={(value) => updateContent("about.title", value)}
          />
          <TextField
            label="Introduction"
            value={content.about.description}
            multiline
            onChange={(value) => updateContent("about.description", value)}
          />
          <TextField
            label="Highlights (one per line)"
            value={content.about.highlights.join("\n")}
            multiline
            onChange={(value) =>
              updateContent(
                "about.highlights",
                value
                  .split("\n")
                  .map((line) => line.trim())
                  .filter(Boolean)
                  .slice(0, 8),
              )
            }
          />
        </div>
      </section>
      <section className="editor-panel">
        <div className="editor-panel-heading">
          <span>03</span>
          <div>
            <h2>Contact & location</h2>
            <p>Keep every detail accurate and up to date.</p>
          </div>
        </div>
        <div className="editor-fields-grid">
          <TextField
            label="Phone number"
            value={content.contact.phone}
            onChange={(value) => updateContent("contact.phone", value)}
          />
          <TextField
            label="WhatsApp number (international format)"
            value={content.contact.whatsapp}
            onChange={(value) => updateContent("contact.whatsapp", value)}
          />
          <TextField
            label="Email address"
            value={content.contact.email}
            onChange={(value) => updateContent("contact.email", value)}
          />
          <TextField
            label="Street address"
            value={content.contact.address}
            onChange={(value) => updateContent("contact.address", value)}
          />
          <TextField
            label="Google Maps embed URL"
            value={content.contact.mapsEmbedUrl}
            onChange={(value) => updateContent("contact.mapsEmbedUrl", value)}
          />
          <TextField
            label="Directions link"
            value={content.contact.directionsUrl}
            onChange={(value) => updateContent("contact.directionsUrl", value)}
          />
          <TextField
            label="Privacy notice URL"
            value={content.contact.privacyUrl}
            onChange={(value) => updateContent("contact.privacyUrl", value)}
          />
        </div>
        <div className="hours-editor">
          <div className="hours-editor-header">
            <strong>Opening hours</strong>
            <span>These hours determine available booking times.</span>
          </div>
          {content.contact.openingHours.map((hours, index) => (
            <div className="hours-editor-row" key={hours.day}>
              <span>{hours.day}</span>
              <label>
                <span className="sr-only">Opens</span>
                <Input
                  type="time"
                  value={hours.open}
                  disabled={hours.closed}
                  onChange={(event) =>
                    updateContent(`contact.openingHours.${index}.open`, event.target.value)
                  }
                />
              </label>
              <label>
                <span className="sr-only">Closes</span>
                <Input
                  type="time"
                  value={hours.close}
                  disabled={hours.closed}
                  onChange={(event) =>
                    updateContent(`contact.openingHours.${index}.close`, event.target.value)
                  }
                />
              </label>
              <label className="closed-check">
                <input
                  type="checkbox"
                  checked={hours.closed}
                  onChange={(event) =>
                    updateContent(`contact.openingHours.${index}.closed`, event.target.checked)
                  }
                />
                <span>Closed</span>
              </label>
            </div>
          ))}
        </div>
        <label className="business-verified-check">
          <input
            type="checkbox"
            checked={content.contact.businessInfoVerified}
            onChange={(event) =>
              updateContent("contact.businessInfoVerified", event.target.checked)
            }
          />
          <span>
            <strong>I confirm these are verified business details</strong>
            <small>
              Only enable this after confirming the real business address and contact information.
            </small>
          </span>
        </label>
      </section>
      <section className="editor-panel">
        <div className="editor-panel-heading">
          <span>04</span>
          <div>
            <h2>Search & sharing</h2>
            <p>Use accurate wording that reflects your business.</p>
          </div>
        </div>
        <div className="editor-fields-grid">
          <TextField
            label="SEO page title"
            value={content.seo.title}
            maxLength={70}
            onChange={(value) => updateContent("seo.title", value)}
          />
          <TextField
            label="SEO description"
            value={content.seo.description}
            multiline
            maxLength={240}
            onChange={(value) => updateContent("seo.description", value)}
          />
        </div>
      </section>
      <div className="editor-bottom-save">
        <span>Check all information before publishing.</span>
        <Button className="gym-button gym-button-red" onClick={() => void saveSite(content)}>
          Save changes <Check size={16} />
        </Button>
      </div>
    </div>
  );
}

function CollectionEditor({
  type,
  content,
  updateContent,
  saveSite,
  previewSite,
  csrf,
}: {
  type: CollectionKey;
  content: GymContent;
  updateContent: (path: string, value: unknown) => void;
  saveSite: (content: GymContent) => Promise<void>;
  previewSite: (content: GymContent) => void;
  csrf: string;
}) {
  const items = content[type] as CollectionItem[];
  const fields = collectionFields[type];
  const title = tabs.find((entry) => entry.id === type)?.label ?? type;

  async function uploadImage(file: File, itemIndex: number) {
    const data = new FormData();
    data.append("image", file);
    try {
      const response = await fetch(`${getGymApiBase()}/admin/uploads`, {
        method: "POST",
        credentials: "include",
        headers: { "X-CSRF-Token": csrf, Accept: "application/json" },
        body: data,
      });
      const result = (await response.json()) as { url?: string; error?: string };
      if (!response.ok || !result.url) throw new Error(result.error ?? "Image upload failed.");
      updateContent(
        `${type}.${itemIndex}.imageUrl`,
        result.url.startsWith("http") ? result.url : `${getGymApiBase()}${result.url}`,
      );
    } catch (error) {
      window.alert(error instanceof Error ? error.message : "Image upload failed.");
    }
  }

  function moveItem(index: number, shift: -1 | 1) {
    const target = index + shift;
    if (target < 0 || target >= items.length) return;
    const reordered = [...items];
    const currentItem = reordered[index];
    const targetItem = reordered[target];
    if (!currentItem || !targetItem) return;
    reordered[index] = targetItem;
    reordered[target] = currentItem;
    updateContent(type, reordered);
  }

  return (
    <div className="collection-editor">
      <div className="editor-intro">
        <p>
          Manage the {title.toLowerCase()} shown on the public page. Changes are saved to your
          connected service.
        </p>
        <Button
          variant="outline"
          className="admin-refresh-button"
          onClick={() => updateContent(type, [...items, structuredClone(blankItems[type])])}
        >
          <Plus size={16} />
          Add{" "}
          {type === "plans"
            ? "plan"
            : type === "trainers"
              ? "trainer"
              : type === "gallery"
                ? "image"
                : type === "classes"
                  ? "class"
                  : "story"}
        </Button>
      </div>
      {items.length ? (
        <div className="collection-items">
          {items.map((item, index) => {
            if (!item) return null;
            const imageUrl = item["imageUrl"];
            const imageAlt = item["imageAlt"];
            const caption = item["caption"];
            return (
              <article className="collection-item" key={`${type}-${index}`}>
                <div className="collection-item-top">
                  <span className="collection-index">{String(index + 1).padStart(2, "0")}</span>
                  <div className="collection-reorder">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => moveItem(index, -1)}
                      disabled={index === 0}
                      aria-label="Move item up"
                    >
                      <ArrowUp size={16} />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => moveItem(index, 1)}
                      disabled={index === items.length - 1}
                      aria-label="Move item down"
                    >
                      <ArrowDown size={16} />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="delete-item"
                      onClick={() =>
                        updateContent(
                          type,
                          items.filter((_, itemIndex) => itemIndex !== index),
                        )
                      }
                      aria-label="Delete item"
                    >
                      <Trash2 size={16} />
                    </Button>
                  </div>
                </div>
                {type === "gallery" && imageUrl && (
                  <img
                    className="collection-preview-image"
                    src={String(imageUrl)}
                    alt={String(imageAlt || caption || "Gallery preview")}
                  />
                )}
                {fields.map((field) => (
                  <div className="collection-field-wrap" key={field.key}>
                    <TextField
                      label={field.label}
                      value={(() => {
                        const fieldValue = item[field.key];
                        return Array.isArray(fieldValue)
                          ? fieldValue.join("\n")
                          : typeof fieldValue === "string"
                            ? fieldValue
                            : "";
                      })()}
                      multiline={field.multiline ?? false}
                      onChange={(value) =>
                        updateContent(
                          `${type}.${index}.${field.key}`,
                          field.key === "features"
                            ? value
                                .split("\n")
                                .map((line) => line.trim())
                                .filter(Boolean)
                                .slice(0, 20)
                            : value,
                        )
                      }
                    />
                    {field.image && (
                      <label className="upload-control">
                        <ImagePlus size={16} />
                        Upload image
                        <input
                          type="file"
                          accept="image/jpeg,image/png,image/webp"
                          onChange={(event: ChangeEvent<HTMLInputElement>) => {
                            const file = event.target.files?.[0];
                            if (file) void uploadImage(file, index);
                            event.target.value = "";
                          }}
                        />
                      </label>
                    )}
                  </div>
                ))}
              </article>
            );
          })}
        </div>
      ) : (
        <div className="admin-empty collection-empty">
          <ImagePlus size={24} />
          <strong>No {title.toLowerCase()} added yet</strong>
          <p>
            Add confirmed details here. Nothing is presented as a real offer until you enter it.
          </p>
          <Button
            variant="outline"
            onClick={() => updateContent(type, [structuredClone(blankItems[type])])}
          >
            <Plus size={16} />
            Add the first item
          </Button>
        </div>
      )}
      <div className="editor-bottom-save">
        <span>Preview your changes, then save to publish on the public website.</span>
        <Button variant="outline" onClick={() => previewSite(content)}>
          Preview draft
        </Button>
        <Button className="gym-button gym-button-red" onClick={() => void saveSite(content)}>
          Save {title.toLowerCase()} <Check size={16} />
        </Button>
      </div>
    </div>
  );
}
