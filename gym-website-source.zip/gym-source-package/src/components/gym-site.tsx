import { useEffect, useMemo, useState } from "react";
import {
  ArrowDown,
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  Check,
  Clock3,
  Dumbbell,
  Instagram,
  MapPin,
  Menu,
  Phone,
  ShieldCheck,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  bookingSchema,
  defaultGymContent,
  getAvailableSlots,
  mergeGymContent,
  type GymContent,
} from "@/lib/gym-content";
import { gymApi, isGymApiConfigured } from "@/lib/gym-api";
import coachImage from "@/assets/trainer-coach.jpg";
import trainingImage from "@/assets/gym-training.jpg";

type BookingResponse = { reference: string; status: string };

const sectionLinks = [
  ["About", "about"],
  ["Membership", "membership"],
  ["Coaches", "coaches"],
  ["Training floor", "gallery"],
  ["Classes", "classes"],
  ["Contact", "contact"],
];

const todayISO = () => {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
};

function useGymContent() {
  const [content, setContent] = useState<GymContent>(defaultGymContent);
  useEffect(() => {
    if (!isGymApiConfigured()) return;
    let active = true;
    gymApi<{ content: unknown }>("/public/site")
      .then(({ content: remote }) => {
        if (active) setContent(mergeGymContent(remote));
      })
      .catch(() => undefined);
    return () => {
      active = false;
    };
  }, []);
  return content;
}

function SectionHeading({
  eyebrow,
  title,
  aside,
}: {
  eyebrow: string;
  title: string;
  aside?: string;
}) {
  return (
    <div className="section-heading">
      <div>
        <p className="eyebrow">
          <span className="eyebrow-mark" />
          {eyebrow}
        </p>
        <h2>{title}</h2>
      </div>
      {aside && <p className="section-aside">{aside}</p>}
    </div>
  );
}

function BookingForm({ content }: { content: GymContent }) {
  const [form, setForm] = useState({
    fullName: "",
    phone: "",
    email: "",
    appointmentDate: "",
    timeSlot: "",
    purpose: "Gym Tour",
    message: "",
    privacyConsent: false,
  });
  const [slots, setSlots] = useState<string[]>([]);
  const [blockedSlots, setBlockedSlots] = useState<string[]>([]);
  const [notice, setNotice] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [saving, setSaving] = useState(false);
  const bookingOpenHours = content.contact.openingHours;

  useEffect(() => {
    if (!form.appointmentDate) {
      setSlots([]);
      return;
    }
    const localSlots = getAvailableSlots(form.appointmentDate, bookingOpenHours, blockedSlots);
    setSlots(localSlots);
    setForm((current) => ({
      ...current,
      timeSlot: localSlots.includes(current.timeSlot) ? current.timeSlot : "",
    }));
  }, [form.appointmentDate, blockedSlots, bookingOpenHours]);

  useEffect(() => {
    if (!form.appointmentDate || !isGymApiConfigured()) {
      setBlockedSlots([]);
      return;
    }
    let active = true;
    gymApi<{ slots: string[] }>(
      `/public/bookings/slots?date=${encodeURIComponent(form.appointmentDate)}`,
    )
      .then(({ slots: unavailable }) => {
        if (active) setBlockedSlots(unavailable);
      })
      .catch(() => {
        if (active) setBlockedSlots([]);
      });
    return () => {
      active = false;
    };
  }, [form.appointmentDate]);

  const updateField = (key: string, value: string | boolean) => {
    setForm((current) => ({ ...current, [key]: value }));
    if (notice) setNotice(null);
  };

  async function submitBooking(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setNotice(null);
    const parsed = bookingSchema.safeParse(form);
    if (!parsed.success) {
      setNotice({
        type: "error",
        text: parsed.error.issues[0]?.message ?? "Check the details and try again.",
      });
      return;
    }
    if (!slots.includes(parsed.data.timeSlot)) {
      setNotice({
        type: "error",
        text: "Choose an available time during the gym's confirmed opening hours.",
      });
      return;
    }
    setSaving(true);
    try {
      const result = await gymApi<BookingResponse>("/public/bookings", {
        method: "POST",
        body: JSON.stringify(parsed.data),
      });
      setNotice({
        type: "success",
        text: `Your request is saved as pending. Reference: ${result.reference}`,
      });
      setForm({
        fullName: "",
        phone: "",
        email: "",
        appointmentDate: "",
        timeSlot: "",
        purpose: "Gym Tour",
        message: "",
        privacyConsent: false,
      });
      setSlots([]);
    } catch (error) {
      setNotice({
        type: "error",
        text:
          error instanceof Error
            ? error.message
            : "The request could not be saved. Please try again.",
      });
    } finally {
      setSaving(false);
    }
  }

  const inputClass = "gym-input";
  return (
    <form className="booking-form" onSubmit={submitBooking} noValidate>
      <div className="booking-grid">
        <label className="form-field">
          Full name
          <input
            className={inputClass}
            name="fullName"
            autoComplete="name"
            required
            maxLength={120}
            value={form.fullName}
            onChange={(event) => updateField("fullName", event.target.value)}
            placeholder="Your name"
          />
        </label>
        <label className="form-field">
          Phone number
          <input
            className={inputClass}
            name="phone"
            type="tel"
            autoComplete="tel"
            required
            maxLength={30}
            value={form.phone}
            onChange={(event) => updateField("phone", event.target.value)}
            placeholder="+1 555 000 0000"
          />
        </label>
        <label className="form-field">
          Email address
          <input
            className={inputClass}
            name="email"
            type="email"
            autoComplete="email"
            required
            maxLength={254}
            value={form.email}
            onChange={(event) => updateField("email", event.target.value)}
            placeholder="you@example.com"
          />
        </label>
        <label className="form-field">
          Appointment date
          <input
            className={inputClass}
            name="appointmentDate"
            type="date"
            min={todayISO()}
            required
            value={form.appointmentDate}
            onChange={(event) => updateField("appointmentDate", event.target.value)}
          />
        </label>
        <label className="form-field">
          Available time
          <select
            className={inputClass}
            name="timeSlot"
            required
            value={form.timeSlot}
            onChange={(event) => updateField("timeSlot", event.target.value)}
            disabled={!form.appointmentDate || slots.length === 0}
          >
            <option value="">
              {!form.appointmentDate
                ? "Select a date first"
                : slots.length
                  ? "Select a time"
                  : "No available times"}
            </option>
            {slots.map((slot) => (
              <option key={slot} value={slot}>
                {slot}
              </option>
            ))}
          </select>
        </label>
        <label className="form-field">
          I’m interested in
          <select
            className={inputClass}
            name="purpose"
            value={form.purpose}
            onChange={(event) => updateField("purpose", event.target.value)}
          >
            <option>Gym Tour</option>
            <option>Free Trial</option>
            <option>Personal Training Consultation</option>
            <option>Membership Enquiry</option>
          </select>
        </label>
        <label className="form-field form-field-wide">
          Anything we should know?
          <textarea
            className={`${inputClass} gym-textarea`}
            name="message"
            rows={3}
            maxLength={1000}
            value={form.message}
            onChange={(event) => updateField("message", event.target.value)}
            placeholder="Optional message"
          />
        </label>
      </div>
      <label className="consent-row">
        <input
          type="checkbox"
          checked={form.privacyConsent}
          onChange={(event) => updateField("privacyConsent", event.target.checked)}
        />
        <span>
          I agree to the{" "}
          <a
            href={content.contact.privacyUrl || "#privacy-information"}
            target={content.contact.privacyUrl ? "_blank" : undefined}
            rel={content.contact.privacyUrl ? "noreferrer" : undefined}
          >
            privacy notice
          </a>{" "}
          and understand my details will be used to respond to this request.
        </span>
      </label>
      {!content.contact.privacyUrl && (
        <p className="setup-inline privacy-setup-notice" id="privacy-information" role="status">
          The gym owner needs to add the real privacy notice before bookings can be accepted.
        </p>
      )}
      {notice && (
        <p
          className={`form-notice form-notice-${notice.type}`}
          role={notice.type === "error" ? "alert" : "status"}
        >
          {notice.type === "success" && <Check size={17} aria-hidden="true" />}
          {notice.text}
        </p>
      )}
      {!isGymApiConfigured() && (
        <p className="setup-inline" role="status">
          Online booking is not connected yet. Your request will not be sent until the gym owner
          configures the secure booking service.
        </p>
      )}
      <Button
        type="submit"
        className="gym-button gym-button-red booking-submit"
        disabled={saving || !content.contact.privacyUrl}
      >
        {saving ? "Sending request…" : "Request an appointment"}
        <ArrowRight size={18} aria-hidden="true" />
      </Button>
    </form>
  );
}

export function GymSite() {
  const liveContent = useGymContent();
  const [previewContent, setPreviewContent] = useState<GymContent | null>(null);
  const [previewMode, setPreviewMode] = useState(false);
  const content = previewContent ?? liveContent;
  const [menuOpen, setMenuOpen] = useState(false);
  const hoursSummary = useMemo(() => {
    const firstOpen = content.contact.openingHours.find(
      (hours) => !hours.closed && hours.open && hours.close,
    );
    return firstOpen ? `${firstOpen.open} – ${firstOpen.close}` : "Hours to be confirmed";
  }, [content.contact.openingHours]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("preview") !== "gym") return;
    setPreviewMode(true);
    const receivePreview = (event: MessageEvent<unknown>) => {
      if (event.origin !== window.location.origin || event.source !== window.opener) return;
      if (
        event.data &&
        typeof event.data === "object" &&
        "type" in event.data &&
        event.data.type === "gym-preview-content" &&
        "content" in event.data
      ) {
        setPreviewContent(mergeGymContent(event.data.content));
      }
    };
    window.addEventListener("message", receivePreview);
    window.opener?.postMessage({ type: "gym-preview-ready" }, window.location.origin);
    return () => window.removeEventListener("message", receivePreview);
  }, []);

  useEffect(() => {
    document.title = content.seo.title || content.brand.name;
    const accent = /^#[0-9a-f]{6}$/i.test(content.brand.accentColor)
      ? content.brand.accentColor
      : "oklch(0.63 0.23 27)";
    document.documentElement.style.setProperty("--gym-red", accent);
    const favicon = document.head.querySelector<HTMLLinkElement>('link[rel="icon"]');
    if (favicon) {
      const faviconUrl = content.brand.faviconUrl;
      favicon.href =
        faviconUrl.startsWith("https://") || faviconUrl.startsWith("/uploads/")
          ? faviconUrl
          : "/favicon.ico";
    }
    const description = content.seo.description || content.hero.description;
    for (const selector of ['meta[name="description"]', 'meta[property="og:description"]']) {
      const meta = document.head.querySelector<HTMLMetaElement>(selector);
      if (meta) meta.content = description;
    }
    const ogTitle = document.head.querySelector<HTMLMetaElement>('meta[property="og:title"]');
    if (ogTitle) ogTitle.content = content.seo.title || content.brand.name;
    const existingSchema = document.head.querySelector('script[data-gym-schema="true"]');
    existingSchema?.remove();
    if (!content.contact.businessInfoVerified || !content.contact.address) return;
    const schema = document.createElement("script");
    schema.type = "application/ld+json";
    schema.dataset["gymSchema"] = "true";
    schema.textContent = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "HealthClub",
      name: content.brand.name,
      description: content.seo.description,
      address: { "@type": "PostalAddress", streetAddress: content.contact.address },
      ...(content.contact.phone ? { telephone: content.contact.phone } : {}),
      ...(content.contact.email ? { email: content.contact.email } : {}),
      ...(content.contact.mapsEmbedUrl ? { hasMap: content.contact.mapsEmbedUrl } : {}),
      openingHoursSpecification: content.contact.openingHours
        .filter((hours) => !hours.closed && hours.open && hours.close)
        .map((hours) => ({
          "@type": "OpeningHoursSpecification",
          dayOfWeek: `https://schema.org/${hours.day}`,
          opens: hours.open,
          closes: hours.close,
        })),
    });
    document.head.append(schema);
    return () => {
      schema.remove();
    };
  }, [content]);

  const brandImage =
    content.brand.logoUrl.startsWith("https://") || content.brand.logoUrl.startsWith("/uploads/")
      ? content.brand.logoUrl
      : "";

  return (
    <main className="gym-shell">
      {previewMode && (
        <div className="preview-banner">
          <span>UNSAVED PREVIEW</span>
          <span>Only visible in this preview window.</span>
          <Button variant="ghost" size="sm" onClick={() => window.close()}>
            Close preview <X size={15} />
          </Button>
        </div>
      )}
      <div className="topline">
        <span className="status-dot" />
        YOUR NEXT CHAPTER STARTS HERE
        <span className="topline-right">A GYM SITE PREVIEW · DETAILS ARE EDITABLE</span>
      </div>
      <header className="gym-header">
        <a href="#top" className="brand-lockup" aria-label={`${content.brand.name} home`}>
          <span className="brand-mark">
            {brandImage ? (
              <img src={brandImage} alt="" />
            ) : (
              <Dumbbell size={23} strokeWidth={2.5} aria-hidden="true" />
            )}
          </span>
          <span className="brand-wordmark">
            <strong>{content.brand.name}</strong>
            <span>{content.brand.descriptor}</span>
          </span>
        </a>
        <nav
          id="main-nav"
          className={`desktop-nav ${menuOpen ? "desktop-nav-open" : ""}`}
          aria-label="Main navigation"
        >
          {sectionLinks.map(([label, id]) => (
            <a key={id} href={`#${id}`} onClick={() => setMenuOpen(false)}>
              {label}
            </a>
          ))}
          <a href="#book" className="mobile-book-link" onClick={() => setMenuOpen(false)}>
            Book a visit <ArrowUpRight size={16} />
          </a>
        </nav>
        <Button asChild className="gym-button gym-button-nav">
          <a href="#book">
            Book a visit <ArrowUpRight size={17} aria-hidden="true" />
          </a>
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="menu-toggle"
          onClick={() => setMenuOpen((open) => !open)}
          aria-label={menuOpen ? "Close menu" : "Open menu"}
          aria-expanded={menuOpen}
          aria-controls="main-nav"
        >
          {menuOpen ? <X /> : <Menu />}
        </Button>
      </header>

      <section
        id="top"
        className="gym-hero"
        style={{
          backgroundImage: `linear-gradient(90deg, var(--hero-shade-left), var(--hero-shade-right)), url("${content.hero.imageUrl}")`,
        }}
        aria-label="Gym introduction"
      >
        <div className="hero-content">
          <p className="eyebrow hero-eyebrow">
            <span className="eyebrow-mark" />
            {content.hero.eyebrow}
          </p>
          <h1>
            {content.hero.title.split("\n").map((line, index) => (
              <span key={line}>
                {index === 1 ? (
                  <>
                    <span>{line.replace(".", "")}</span>
                    <i>.</i>
                  </>
                ) : (
                  line
                )}
              </span>
            ))}
          </h1>
          <p className="hero-copy">{content.hero.description}</p>
          <div className="hero-actions">
            <Button asChild className="gym-button gym-button-red">
              <a href="#membership">
                {content.hero.primaryLabel}
                <ArrowRight size={18} aria-hidden="true" />
              </a>
            </Button>
            <Button asChild variant="outline" className="gym-button gym-button-outline">
              <a href="#book">
                {content.hero.secondaryLabel}
                <ArrowDownRight size={18} aria-hidden="true" />
              </a>
            </Button>
          </div>
          <div className="hero-bottom">
            <span>
              <span className="hero-coordinates">01 / 05</span> &nbsp; BUILT FOR WHAT'S NEXT
            </span>
            <a href="#about">
              SCROLL TO EXPLORE <ArrowDown size={14} aria-hidden="true" />
            </a>
          </div>
        </div>
        <div className="hero-index">
          EST. <span>YOUR YEAR</span>
        </div>
      </section>

      <section className="trust-strip" aria-label="Gym values">
        <span>COACHING THAT MEETS YOU HERE</span>
        <span className="trust-divider" />
        <span>SPACE TO GET STRONGER</span>
        <span className="trust-divider" />
        <span>COMMUNITY WITHOUT THE EGO</span>
      </section>

      <section id="about" className="section-block about-section">
        <SectionHeading eyebrow="THE PLACE" title={content.about.title} aside="A little about us" />
        <div className="about-layout">
          <div className="about-lead">
            <span className="section-number">01 — THE APPROACH</span>
            <p>{content.about.description}</p>
            <a className="text-link" href="#contact">
              Get to know the gym <ArrowRight size={17} aria-hidden="true" />
            </a>
          </div>
          <div className="about-highlights">
            {content.about.highlights.map((highlight, index) => (
              <div className="about-highlight" key={`${highlight}-${index}`}>
                <span>0{index + 1}</span>
                <p>{highlight}</p>
                <ArrowUpRight size={17} aria-hidden="true" />
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="membership" className="membership-section section-block">
        <SectionHeading
          eyebrow="FIND YOUR FIT"
          title="Membership, your way."
          aside="A plan for the work you want to do."
        />
        {content.plans.length ? (
          <div className="plan-grid">
            {content.plans.map((plan, index) => (
              <article
                className={`plan-card ${index === 1 ? "plan-card-featured" : ""}`}
                key={`${plan.name}-${index}`}
              >
                <div className="plan-topline">
                  <span>0{index + 1} / MEMBERSHIP</span>
                  {index === 1 && <span className="plan-featured-label">MOST POPULAR</span>}
                </div>
                <h3>{plan.name}</h3>
                <p className="plan-description">{plan.description}</p>
                <p className="plan-price">
                  {plan.price}
                  <span>{plan.period}</span>
                </p>
                <ul>
                  {plan.features.map((feature) => (
                    <li key={feature}>
                      <Check size={15} aria-hidden="true" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Button asChild variant="outline" className="gym-button gym-button-plan">
                  <a href="#book">
                    Enquire about this plan <ArrowRight size={17} />
                  </a>
                </Button>
              </article>
            ))}
          </div>
        ) : (
          <div className="empty-content-row">
            <span className="section-number">MEMBERSHIP OPTIONS</span>
            <p>Membership details are being prepared. Ask us about your options.</p>
            <a className="text-link" href="#book">
              Enquire about membership <ArrowRight size={17} />
            </a>
          </div>
        )}
      </section>

      <section id="coaches" className="coaches-section section-block">
        <SectionHeading
          eyebrow="GOOD PEOPLE. GOOD COACHING."
          title="Meet your crew."
          aside="Coaching begins with a conversation."
        />
        {content.trainers.length ? (
          <div className="trainer-grid">
            {content.trainers.map((trainer, index) => (
              <article className="trainer-card" key={`${trainer.name}-${index}`}>
                <img
                  src={trainer.imageUrl || coachImage}
                  alt={trainer.imageAlt || `${trainer.name}, ${trainer.specialty} coach`}
                  loading="lazy"
                  width={912}
                  height={1200}
                />
                <div className="trainer-caption">
                  <div>
                    <span>{trainer.specialty}</span>
                    <h3>{trainer.name}</h3>
                    <p>{trainer.bio}</p>
                  </div>
                  <ArrowUpRight size={20} aria-hidden="true" />
                </div>
              </article>
            ))}
          </div>
        ) : (
          <div className="empty-content-row">
            <span className="section-number">MEET THE COACHES</span>
            <p>Coach profiles and specialties will appear here once confirmed.</p>
          </div>
        )}
      </section>

      <section id="gallery" className="gallery-section section-block">
        <SectionHeading
          eyebrow="INSIDE THE GYM"
          title="Built for the work."
          aside="A look around the training floor."
        />
        <div className="gallery-grid">
          {content.gallery.map((image, index) => (
            <figure
              className={`gallery-figure gallery-figure-${index + 1}`}
              key={`${image.imageUrl}-${index}`}
            >
              <img
                src={image.imageUrl || trainingImage}
                alt={image.imageAlt || image.caption}
                loading="lazy"
                width={1200}
                height={900}
              />
              <figcaption>
                <span>
                  0{index + 1} / {image.caption}
                </span>
                <ArrowUpRight size={16} aria-hidden="true" />
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section id="classes" className="classes-section section-block">
        <SectionHeading
          eyebrow="MOVE TOGETHER"
          title="Find your rhythm."
          aside="Small groups. Skilled coaches. Your next session."
        />
        {content.classes.length ? (
          <div className="class-list">
            {content.classes.map((session, index) => (
              <article className="class-row" key={`${session.name}-${index}`}>
                <span className="class-number">0{index + 1}</span>
                <div className="class-main">
                  <h3>{session.name}</h3>
                  <p>{session.description}</p>
                </div>
                <span className="class-schedule">{session.schedule}</span>
                <span className="class-capacity">{session.capacity}</span>
                <ArrowUpRight size={18} aria-hidden="true" />
              </article>
            ))}
          </div>
        ) : (
          <div className="empty-content-row">
            <span className="section-number">CLASS SCHEDULE</span>
            <p>Classes and weekly sessions will be listed once the schedule is confirmed.</p>
          </div>
        )}
      </section>

      <section className="quote-section section-block">
        <span className="quote-mark">“</span>
        {content.testimonials.length ? (
          <div className="testimonial-list">
            {content.testimonials.map((testimonial, index) => (
              <article className="testimonial-item" key={`${testimonial.name}-${index}`}>
                <p>{testimonial.quote}</p>
                <span className="quote-byline">
                  {testimonial.name}
                  {testimonial.memberSince ? ` · ${testimonial.memberSince}` : ""}
                </span>
              </article>
            ))}
          </div>
        ) : (
          <>
            <p>Real stories from members belong here.</p>
            <span className="quote-byline">No reviews have been published for this preview.</span>
          </>
        )}
        <div className="quote-navigation">
          <span>MEMBER STORIES / {String(content.testimonials.length).padStart(2, "0")}</span>
          <span>{content.testimonials.length ? "OWNER MANAGED" : "— — —"}</span>
        </div>
      </section>

      <section id="book" className="booking-section section-block">
        <div className="booking-intro">
          <p className="eyebrow">
            <span className="eyebrow-mark" />
            COME SEE FOR YOURSELF
          </p>
          <h2>
            Start with a<br />
            conversation.
          </h2>
          <p>Tell us a little about what you’re looking for. We’ll take it from there.</p>
          <div className="booking-note">
            <Clock3 size={18} aria-hidden="true" />
            <span>Typical hours preview: {hoursSummary}</span>
          </div>
          <div className="booking-note">
            <ShieldCheck size={18} aria-hidden="true" />
            <span>Your information stays private.</span>
          </div>
        </div>
        <div className="booking-panel">
          <div className="booking-panel-head">
            <span>BOOK A VISIT</span>
            <span>01 / NEW REQUEST</span>
          </div>
          <BookingForm content={content} />
        </div>
      </section>

      <section id="contact" className="contact-section section-block">
        <SectionHeading
          eyebrow="FIND YOUR WAY IN"
          title="Your neighborhood gym."
          aside="Add your verified address and hours before launch."
        />
        <div className="contact-layout">
          <div className="contact-details">
            <div className="contact-row">
              <span>LOCATION</span>
              <p>{content.contact.address || "Gym address not added yet"}</p>
            </div>
            <div className="contact-row">
              <span>PHONE</span>
              <p>
                {content.contact.phone ? (
                  <a href={`tel:${content.contact.phone}`}>{content.contact.phone}</a>
                ) : (
                  "Phone number not added yet"
                )}
              </p>
            </div>
            <div className="contact-row">
              <span>EMAIL</span>
              <p>
                {content.contact.email ? (
                  <a href={`mailto:${content.contact.email}`}>{content.contact.email}</a>
                ) : (
                  "Email address not added yet"
                )}
              </p>
            </div>
            <div className="contact-row">
              <span>OPENING HOURS</span>
              <div className="hours-list">
                {content.contact.openingHours.map((hours) => (
                  <p key={hours.day}>
                    <span>{hours.day}</span>
                    <span>
                      {hours.closed || !hours.open || !hours.close
                        ? "Hours to be confirmed"
                        : `${hours.open} – ${hours.close}`}
                    </span>
                  </p>
                ))}
              </div>
            </div>
            {content.contact.businessInfoVerified ? (
              <p className="verified-note">
                <Check size={15} />
                Business details confirmed
              </p>
            ) : (
              <p className="unverified-note">Business details awaiting owner confirmation</p>
            )}
            <div className="contact-actions">
              {content.contact.directionsUrl && (
                <Button asChild className="gym-button gym-button-red">
                  <a href={content.contact.directionsUrl} target="_blank" rel="noreferrer">
                    Get directions <ArrowUpRight size={17} />
                  </a>
                </Button>
              )}
              {content.contact.whatsapp && (
                <Button asChild variant="outline" className="gym-button gym-button-outline">
                  <a
                    href={`https://wa.me/${content.contact.whatsapp.replace(/\D/g, "")}`}
                    target="_blank"
                    rel="noreferrer"
                  >
                    WhatsApp <Phone size={16} />
                  </a>
                </Button>
              )}
            </div>
          </div>
          <div className="map-frame">
            {content.contact.mapsEmbedUrl ? (
              <iframe
                src={content.contact.mapsEmbedUrl}
                title={`Map for ${content.brand.name}`}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                allowFullScreen
              />
            ) : (
              <div className="map-empty">
                <MapPin size={30} aria-hidden="true" />
                <span>MAP LOCATION NOT ADDED</span>
                <p>A verified business address will bring the map to life.</p>
              </div>
            )}
          </div>
        </div>
      </section>

      <footer className="gym-footer">
        <a href="#top" className="brand-lockup footer-brand">
          <span className="brand-mark">
            {brandImage ? (
              <img src={brandImage} alt="" />
            ) : (
              <Dumbbell size={23} strokeWidth={2.5} aria-hidden="true" />
            )}
          </span>
          <span className="brand-wordmark">
            <strong>{content.brand.name}</strong>
            <span>{content.brand.descriptor}</span>
          </span>
        </a>
        <p className="footer-copy">{content.brand.tagline}</p>
        <div className="footer-links">
          <a href="#about">About</a>
          <a href="#membership">Membership</a>
          <a href="#contact">Contact</a>
          {content.contact.privacyUrl && (
            <a href={content.contact.privacyUrl} target="_blank" rel="noreferrer">
              Privacy
            </a>
          )}
          {content.contact.phone && <a href={`tel:${content.contact.phone}`}>Call us</a>}
          {content.brand.instagramUrl && (
            <a
              href={content.brand.instagramUrl}
              aria-label="Instagram"
              target="_blank"
              rel="noreferrer"
            >
              <Instagram size={17} aria-hidden="true" />
            </a>
          )}
          {content.brand.facebookUrl && (
            <a
              href={content.brand.facebookUrl}
              aria-label="Facebook"
              target="_blank"
              rel="noreferrer"
            >
              f
            </a>
          )}
          {content.brand.youtubeUrl && (
            <a
              href={content.brand.youtubeUrl}
              aria-label="YouTube"
              target="_blank"
              rel="noreferrer"
            >
              ▶
            </a>
          )}
        </div>
        <p className="footer-legal">
          © {new Date().getFullYear()} {content.brand.name}.{" "}
          <span>Business details and social links are owner-managed.</span>
        </p>
      </footer>
      <a href="#book" className="mobile-book-float">
        BOOK A VISIT <ArrowUpRight size={16} aria-hidden="true" />
      </a>
    </main>
  );
}
