import { describe, expect, it } from "vitest";
import { bookingSchema, getAvailableSlots, isBookingDateAllowed } from "@/lib/gym-content";

const today = new Date(2026, 9, 26, 12, 0, 0);
const tomorrow = new Date();
tomorrow.setDate(tomorrow.getDate() + 1);
const tomorrowISO = `${tomorrow.getFullYear()}-${String(tomorrow.getMonth() + 1).padStart(2, "0")}-${String(tomorrow.getDate()).padStart(2, "0")}`;

describe("gym booking rules", () => {
  it("accepts today and future dates but rejects yesterday", () => {
    expect(isBookingDateAllowed("2026-10-26", today)).toBe(true);
    expect(isBookingDateAllowed("2026-10-27", today)).toBe(true);
    expect(isBookingDateAllowed("2026-10-25", today)).toBe(false);
  });

  it("creates hourly starts inside opening hours and excludes confirmed slots", () => {
    const openingHours = [{ day: "Monday", open: "09:30", close: "12:00", closed: false }];
    expect(getAvailableSlots("2026-10-26", openingHours, ["10:00"], today)).toEqual(["11:00"]);
  });

  it("does not offer a slot when the selected day is closed", () => {
    expect(
      getAvailableSlots(
        "2026-10-26",
        [{ day: "Monday", open: "09:00", close: "18:00", closed: true }],
        [],
        today,
      ),
    ).toEqual([]);
  });

  it("requires consent, a valid contact, purpose and an hourly time", () => {
    const booking = {
      fullName: "Alex Morgan",
      phone: "+1 555 010 2000",
      email: "alex@example.com",
      appointmentDate: tomorrowISO,
      timeSlot: "10:00",
      purpose: "Gym Tour",
      message: "",
      privacyConsent: true,
    };
    expect(bookingSchema.safeParse(booking).success).toBe(true);
    expect(bookingSchema.safeParse({ ...booking, privacyConsent: false }).success).toBe(false);
    expect(bookingSchema.safeParse({ ...booking, purpose: "Walk in" }).success).toBe(false);
    expect(bookingSchema.safeParse({ ...booking, timeSlot: "10:30" }).success).toBe(false);
  });
});
